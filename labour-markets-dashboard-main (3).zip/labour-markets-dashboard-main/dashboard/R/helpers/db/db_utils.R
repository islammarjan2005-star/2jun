
# ---- Render SQL safely when using a Pool-backed remote ----
sql_render_pool_safe <- function(tbl) {
  con <- pool::poolCheckout(APP_DB$pool)
  on.exit(pool::poolReturn(con), add = TRUE)
  dbplyr::sql_render(tbl, con = con)
}

# ---- Generic lazy filter helper usable across datasets ----
# - date_col: name of the date column (Date) to filter (or NULL to skip)
# - where_in:    named list of column -> vector; applies "col %in% values"
# - where_equals:named list of column -> scalar; applies "col == value"
# NOTE: All filters are applied lazily (translated to SQL). No collect() here.
apply_filters_general <- function(
  tbl,
  date_col     = "time_period",
  date_from    = NULL,
  date_to      = NULL,
  where_in     = NULL,
  where_equals = NULL
) {
  stopifnot(inherits(tbl, "tbl_sql") || inherits(tbl, "tbl_lazy") || inherits(tbl, "tbl_dbi"))

  # Date range
  if (!is.null(date_col) && nzchar(date_col)) {
    if (!is.null(date_from)) tbl <- tbl %>% dplyr::filter(.data[[date_col]] >= !!as.Date(date_from))
    if (!is.null(date_to))   tbl <- tbl %>% dplyr::filter(.data[[date_col]] <= !!as.Date(date_to))
  }

  # IN filters
  if (!is.null(where_in) && length(where_in)) {
    for (nm in names(where_in)) {
      vals <- where_in[[nm]]
      if (!is.null(vals) && length(vals)) {
        tbl <- tbl %>% dplyr::filter(.data[[nm]] %in% !!as.character(vals))
      }
    }
  }

  # Equality filters
  if (!is.null(where_equals) && length(where_equals)) {
    for (nm in names(where_equals)) {
      v <- where_equals[[nm]]
      if (!is.null(v) && length(v) == 1L && nzchar(as.character(v))) {
        tbl <- tbl %>% dplyr::filter(.data[[nm]] == !!v)
      }
    }
  }

  tbl
}


get_latest_value_eq <- function(
  schema,
  table,
  date_col,
  filter_col=  NULL,
  filter_value = NULL,
  value_col,
  additional_info = "",
  mode = c("latest", "diff"),
  parse_mode = c("none", "MMM-MMM YYYY", "MMM YYYY", "MMM YY", "CAST_DATE"),
  pool = APP_DB$pool,
  with_tooltip = FALSE,
  date_fmt = "%Y-%m-%d",
  filters = NULL,
  delta_rows_back = 2L,     # e.g. c(2,4,13)
  delta_labels    = NULL    # e.g. c("vs last month","vs last quarter","vs last year")
) {
  mode <- match.arg(mode)
  parse_mode <- match.arg(parse_mode)

  # Normalise new args early (keeps behaviour deterministic)
  delta_rows_back <- as.integer(delta_rows_back)
  if (anyNA(delta_rows_back) || length(delta_rows_back) == 0L) delta_rows_back <- 2L
  # You probably only want comparisons against older rows; keep 2+ by default
  # (but do not silently drop user input)
  if (is.null(delta_labels)) {
    delta_labels <- rep("vs prior", length(delta_rows_back))
  }
  delta_labels <- rep(delta_labels, length.out = length(delta_rows_back))

  base <- dplyr::tbl(pool, dbplyr::in_schema(schema, table))

  date_sql <- .date_sql_for(parse_mode, date_col)
  if (!is.null(date_sql)) {
    base <- base %>% dplyr::mutate(!!date_col := !!date_sql)
  }


# --- FILTERING ---
if (!is.null(filters)) {

  stopifnot(
    is.list(filters),
    !is.null(names(filters)),
    all(nzchar(names(filters)))
  )

  # Build an UNNAMED list of filter expressions
  exprs <- purrr::map(
    names(filters),
    function(col) {
      val <- filters[[col]]

      if (length(val) == 1L) {
        rlang::expr(.data[[!!col]] == !!val)
      } else {
        rlang::expr(.data[[!!col]] %in% !!val)
      }
    }
  )

  filtered <- base %>%
    dplyr::filter(!!!exprs)

} else {

  stopifnot(
    !is.null(filter_col),
    !is.null(filter_value)
  )

  filtered <- base %>%
    dplyr::filter(.data[[filter_col]] == !!filter_value)
}


  if (mode == "latest") {

    if (!with_tooltip) {
      latest_val <- filtered %>%
        dplyr::slice_max(order_by = .data[[date_col]], n = 1, with_ties = FALSE) %>%
        dplyr::pull(var = value_col)

      return(if (length(latest_val) >= 1) latest_val[[1]] else NA_real_)
    }

    # NEW: pull enough rows for the largest row-back requested
    n_need <- max(delta_rows_back, na.rm = TRUE)
    topN <- filtered %>%
      dplyr::slice_max(order_by = .data[[date_col]], n = n_need, with_ties = FALSE) %>%
      dplyr::select(!!date_col, !!value_col) %>%
      dplyr::collect()

    if (nrow(topN) == 0) {
      return(list(
        value   = NA_real_,
        delta   = rep(NA_real_, length(delta_rows_back)),
        period  = delta_labels,
        tooltip = sprintf(
          "Reading taken on %s. Based on variable %s from %s.%s",
          "unknown date", value_col, schema, table
        )
      ))
    }

    # Ensure ordering: latest first
    topN <- topN %>% dplyr::arrange(dplyr::desc(.data[[date_col]]))

    latest_val <- topN[[value_col]][[1]]
    latest_dt  <- topN[[date_col]][[1]]

    # Compute deltas for each requested row-back
    deltas <- vapply(
      delta_rows_back,
      function(k) {
        if (k <= nrow(topN)) {
          prev_val <- topN[[value_col]][[k]]
          if (!is.na(prev_val)) latest_val - prev_val else NA_real_
        } else {
          NA_real_
        }
      },
      numeric(1)
    )

    # Format date robustly for tooltip
    date <- tryCatch({
      if (inherits(latest_dt, "POSIXt")) {
        format(latest_dt, date_fmt, tz = attr(latest_dt, "tzone") %||% "UTC")
      } else if (inherits(latest_dt, "Date")) {
        format(latest_dt, date_fmt)
      } else {
        dt <- suppressWarnings(as.POSIXct(latest_dt, tz = "UTC"))
        if (!is.na(dt)) format(dt, date_fmt, tz = "UTC") else as.character(latest_dt)
      }
    }, error = function(e) as.character(latest_dt))

    filter_txt <- if (!is.null(filters)) {
      paste(paste0(names(filters), "=", vapply(filters, toString, "")), collapse = "; ")
    } else {
      as.character(filter_value)
    }
    
    tooltip <- sprintf(
      "%s. Based on %s from %s.%s. Statistic Date: %s.",
      additional_info, filter_txt, schema, table, date
    )


    return(list(
      value  = latest_val,
      delta  = deltas,        # vector now
      period = delta_labels,  # vector of labels
      tooltip = tooltip,
      date = date
    ))
  }

  # mode == "diff" (keep existing single-diff behaviour)
  vals <- filtered %>%
    dplyr::slice_max(order_by = .data[[date_col]], n = 2, with_ties = FALSE) %>%
    dplyr::pull(var = value_col)

  if (length(vals) < 2) return(NA_real_)
  vals[[1]] - vals[[2]]
}

