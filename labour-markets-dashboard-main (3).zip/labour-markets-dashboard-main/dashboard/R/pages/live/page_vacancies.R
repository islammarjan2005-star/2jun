vacancies_ui <- function(id) {
  ns <- NS(id)
  
    toc_sections <- list(
    list(
      heading = "General",
      items = c("Vacancies by Industry"     = "section-industry",
                "Vacancies by Business Size"= "section-business-size")
    )
    )
    
      tagList(
    # Load in the SideBar Nav
    side_nav(ns, sections = toc_sections, title = "On this page"),
    #Set Up Page
    div(class = "govuk-width-container",
        tags$main(class = "govuk-main-wrapper",
                  tags$h1(class = "govuk-heading-xl", "Vacancies"),
                  tags$h1(class = "mb-0 text-inherit", "General"),
#===== Stats Cards ===== 
                   div(class = "govuk-grid-row",
                    vacancies_overall_kpi_card_ui(ns("overall_vacant_card")),
                    vacancies_hospitality_kpi_card_ui(ns("hosp_vacant_card")),
                    vacancies_retail_kpi_card_ui(ns("retail_vacant_card"))
                                       ),
#===== Overview =====
                  div(class = "govuk-grid-row",
                    div(class = "govuk-grid-column-full",
                    tags$section(id = "section-industry",
                    vacancies_industry_stats_card_ui(ns("industry_card"))
                    ))),
                  div(class = "govuk-grid-row",
                    div(class = "govuk-grid-column-full",
                    tags$section(id = "section-business-size",
                    vacancies_business_size_stats_card_ui(ns("business_size_card"))
                    ))),


)))
    
    
}

vacancies_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    vacancies_industry_stats_card_server("industry_card")
    vacancies_business_size_stats_card_server("business_size_card")
    vacancies_overall_kpi_card_server("overall_vacant_card")
    vacancies_hospitality_kpi_card_server("hosp_vacant_card")
    vacancies_retail_kpi_card_server("retail_vacant_card")
  })
}
