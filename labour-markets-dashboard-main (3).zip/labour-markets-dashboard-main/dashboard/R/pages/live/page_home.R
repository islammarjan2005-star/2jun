
how_to_use_details <- function(ns, content, title) {
  shiny::tags$details(
    class = "govuk-details",
    shiny::tags$summary(
      class = "govuk-details__summary",
      shiny::tags$span(
        class = "govuk-details__summary-text",
        title
      )
    ),
    shiny::tags$div(
      class = "govuk-details__text govuk-body",
      content
    )
  )
}

home_ui <- function(id) {
  ns <- NS(id)
  govuk_page("Home")
  
  tags$div(
  class = "govuk-width-container",
  tags$main(class = "govuk-main-wrapper",
            tags$h1(class = "govuk-heading-xl", "Welcome!"),
            tags$p(
              class = "govuk-body govuk-!-font-weight-bold",
              "This is a \"work in progress\" product. We would love to hear about your experience with the dashboard and welcome any suggested improvements on the following link. To open, right click the link and open in new tab: ",
              tags$a(
                href = "https://forms.office.com/e/twvDRMkzDP",
                class = "govuk-link",
                "Feedback Form"
              )
            ),

            tags$p(class = "govuk-body", "The aim is to have a central, and dynamic source of labour market statistics in order to: "),
            
            htmltools::tags$ul(
              htmltools::tags$li("Assist with policy making, feeding into briefs, slides etc."),
              htmltools::tags$li("Identify emerging trends and changes in the labour market."),
              htmltools::tags$li("Inform and provide input to further analysis and modelling work."),
              htmltools::tags$li("Help to monitor impact of existing policies e.g. Employment Rights Act"),
            ),
            tags$p(class = "govuk-body", "Each visualisation is given a publication marker that gives a quick insight into the type of data behind it."),
            htmltools::tags$ul(
  class = "ukhsa-icon-bullet-list",

            htmltools::tags$li(
              htmltools::tags$img(
                src = "assets/images/tick.png",
                alt = "",                 # decorative icon – correct accessibility
                class = "ukhsa-bullet-icon"
              ),
              htmltools::tags$span("Uses fully published data that is accessible by the entire public. E.g ONS A01 Tables. This means it can easily be used, provided it is given in the correct context and properly cited.")
            ),
          
            htmltools::tags$li(
              htmltools::tags$img(
                src = "assets/images/stop.png",
                alt = "",
                class = "ukhsa-bullet-icon"
              ),
              htmltools::tags$span("Uses partially publicly available micro data. E.g LFS micro data. This means some extra caution and explanation will be needed around how the figures were derived.")
            ),
          
            htmltools::tags$li(
              htmltools::tags$img(
                src = "assets/images/cross.png",
                alt = "",
                class = "ukhsa-bullet-icon"
              ),
              htmltools::tags$span("Uses private micro-data that isn't publicly available. E.g Textkernel vacancies data. This means it would be more difficult to use in a publication, likely requiring an additional statistical release.")
            )
          ),
            tags$p(class = "govuk-body", "In all of these cases, it is still recommended that the user contact the relevant policy analyst to ensure proper framing and citation."),
            tags$p(class = "govuk-body", "While the dashboard has been designed to be as intuitive to use as possible, the section below gives some guidance over its features."),
            how_to_use_details(
              ns = NS("main"),
              title = "How to use the dashboard",
              content = tagList(
                how_to_use_details(
                      ns = NS("main"),
                      title = "Navigation",
                      content = tagList(
                          tags$div(
                            tags$img(
                              src = "assets/images/navigation_graphic.png",
                              alt = "Labour Market Dashboard illustration",
                              class = "govuk-!-margin-bottom-4",
                              style = "max-width: 1000px; height: auto;"
                            ))
                      )),
                how_to_use_details(
                      ns = NS("main"),
                      title = "KPI Cards",
                      content = tagList(
                        tags$h1(class = "govuk-heading-s", "KPI cards"),
                        tags$div(
                            tags$img(
                              src = "assets/images/kpi_card.png",
                              alt = "Labour Market Dashboard illustration",
                              class = "govuk-!-margin-bottom-4",
                              style = "max-width: 1000px; height: auto;"
                            ))
                      )),
                  how_to_use_details(
                      ns = NS("main"),
                      title = "Stats Cards",
                      content = tagList(
                        tags$div(
                            tags$img(
                              src = "assets/images/stats_card.png",
                              alt = "Labour Market Dashboard illustration",
                              class = "govuk-!-margin-bottom-4",
                              style = "max-width: 1000px; height: auto;"
                            )), 
                         how_to_use_details(
                              ns = NS("main"),
                              title = "Chart",
                              content = tagList(
                                  tags$div(
                                    tags$img(
                                          src = "assets/images/graph.png",
                                          alt = "Labour Market Dashboard illustration",
                                          class = "govuk-!-margin-bottom-4",
                                          style = "max-width: 1000px; height: auto;"
                                            )))),
                         
                         how_to_use_details(
                              ns = NS("main"),
                              title = "Table",
                              content = tagList(
                                  tags$div(
                                    tags$img(
                                          src = "assets/images/table.png",
                                          alt = "Labour Market Dashboard illustration",
                                          class = "govuk-!-margin-bottom-4",
                                          style = "max-width: 1000px; height: auto;"
                                        )))),
                         
                         how_to_use_details(
                              ns = NS("main"),
                              title = "Source Data",
                              content = tagList(
                                    tags$div(
                                      tags$img(
                                            src = "assets/images/source_data.png",
                                            alt = "Labour Market Dashboard illustration",
                                            class = "govuk-!-margin-bottom-4",
                                            style = "max-width: 1000px; height: auto;"
                                          )))), 
                         
                         how_to_use_details(
                              ns = NS("main"),
                              title = "Control Panel",
                              content = tagList(
                                      tags$div(
                                        tags$img(
                                              src = "assets/images/control_panel.png",
                                              alt = "Labour Market Dashboard illustration",
                                              class = "govuk-!-margin-bottom-4",
                                              style = "max-width: 1000px; height: auto;"
                                            ))))
                      )
                  )
              )
            )
  )
  )

}

home_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    # Home-specific server logic (add later)
  })
}
