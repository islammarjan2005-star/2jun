
# R/pages/page_unemployment.R

# ---- Unemployment page ----

library(ggplot2)
library(scales)
library(plotly)

# ROUTER PAGE ----------
unemployment_ui <- function(id) {
  ns <- NS(id)

  toc_sections <- list(
    list(
      heading = "General",
      items = c("Economic Activity" = "section-economic-activity"
                )
    ),
        list(
      heading = "Unemployment",
      items = c("Unemployment by age group" = "section-unemp-age"
                )
    ),
        list(
      heading = "Inactivity",
      items = c(
                "Inactivity by age group" = "section-inactivity",
                "Inactivity by reason" = "section-inactivity-reason")
    )
  )

  tagList(
    side_nav(ns, sections = toc_sections, title = "On this page"),
    div(class = "govuk-width-container",
        tags$main(class = "govuk-main-wrapper",
                  tags$h1(class = "govuk-heading-xl", "Unemployment & Inactivity"),
                  tags$h1(class = "mb-0 text-inherit", "General"),
                  
                  div(class = "govuk-grid-row",
                    unemployment_unemploy_kpi_card_ui(ns("unemploy_card")),
                    unemployment_unemploy_rate_kpi_card_ui(ns("unemploy_rate_card")),
                    unemployment_inactive_kpi_card_ui(ns("inactive_card"))

                                       ),
#===== Overview =====
                  div(class = "govuk-grid-row",
                    div(class = "govuk-grid-column-full",
                    tags$section(id = "section-economic-activity",
                    employment_economic_activity_stats_card_ui(ns("economic_activity"))
                    ))),
                  
 tags$h1(class = "mb-0 text-inherit", "Unemployment"),
#===== Unemployment by Age =====
                  div(class = "govuk-grid-row",
                    div(class = "govuk-grid-column-full",
                    tags$section(id = "section-unemp-age",
                    unemployment_age_stats_card_ui(ns("unemp_age_card"))
                    ))),

 tags$h1(class = "mb-0 text-inherit", "Inactivity"),
#===== Inactivity overall =====
                  div(class = "govuk-grid-row",
                    div(class = "govuk-grid-column-full",
                    tags$section(id = "section-inactivity",
                    unemployment_inactivity_stats_card_ui(ns("inact_card"))
                    ))),
#===== Inactivity by reason =====
                  div(class = "govuk-grid-row",
                    div(class = "govuk-grid-column-full",
                    tags$section(id = "section-inactivity-reason",
                    unemployment_inactivity_reason_stats_card_ui(ns("inact_reason_card"))
                    ))),

        ))
  )
}

unemployment_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    unemployment_unemploy_kpi_card_server("unemploy_card")
    unemployment_inactive_kpi_card_server("inactive_card")
    unemployment_unemploy_rate_kpi_card_server("unemploy_rate_card")
    
    unemployment_age_stats_card_server("unemp_age_card")
    employment_economic_activity_stats_card_server("economic_activity")
    unemployment_inactivity_reason_stats_card_server("inact_reason_card")
    unemployment_inactivity_stats_card_server("inact_card")
  })
}
