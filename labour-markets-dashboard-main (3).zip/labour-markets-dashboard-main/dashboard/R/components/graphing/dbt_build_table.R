dbt_build_table <- function(data, formatted_cols) {
  
  # formatting function (your logic)
  fmt_number <- function(value) {
    if (is.na(value)) return("")
    
    if (abs(value) >= 1) {
      format(round(value, 0), big.mark = ",")
    } else {
      format(round(value, 2), nsmall = 2)
    }
  }
  
  # create column definitions dynamically
  cols <- lapply(formatted_cols, function(col) {
    reactable::colDef(cell = fmt_number)
  })
  
  names(cols) <- formatted_cols
  
  # return table
  reactable::reactable(
    data,
    sortable = TRUE,
    filterable = TRUE,
    resizable = TRUE,
    pagination = TRUE,
    highlight = TRUE,
    striped = TRUE,
    defaultPageSize = 25,
    
    style = list(
      fontSize = "12px",
      lineHeight = "1.2"
    ),
    
    columns = cols
  )
}