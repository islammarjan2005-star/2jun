govuk_info_button <- function(
  id,
  text = "",
  icon = c("i", "?", "tick", "cross", "stop"),
  publish_marker = NULL,
  title = NULL,
  corner = c("top-right", "top-left"),  # backwards compatible default
  offset_px   = 12,
  offset_y_px = NULL,
  fg_hex = NULL,
  tick_hex  = "#00703c",
  cross_hex = "#d4351c",
  stop_hex  = "#505a5f",
  bg_hex = "rgba(0,0,0,0.05)",
  tooltip_bg = "#0b0c0c",
  tooltip_fg = "#ffffff"
) {

  # corner can now be NULL (inline/in-flow) OR one of the two placements
  if (!is.null(corner)) {
    corner <- match.arg(corner)  # only validate when not NULL
  }

  # ---- OPTIONAL OVERRIDE: publish_marker ----
  if (!is.null(publish_marker)) {

    publish_marker <- match.arg(
      publish_marker,
      choices = c("public", "public_micro", "private_micro")
    )

    pm <- switch(
      publish_marker,
      "public" = list(
        icon = "tick",
        text = "This visual is based on fully published data and can easily be used in briefings, publications etc. Speak with the relevant policy analyst around proper framing and source acknowledgement."
      ),
      "public_micro" = list(
        icon = "stop",
        text = "This visual is based on partially published micro-data. While it can be used in briefings and publications, extra care needs to be taken. Speak with the relevant policy analyst around proper framing and source acknowledgement."
      ),
      "private_micro" = list(
        icon = "cross",
        text = "This visual is based on micro-data that is not publicly available. Treat as MI data only. Speak with the relevant policy analyst before using in any briefings/publications."
      )
    )

    icon <- pm$icon
    text <- pm$text
  }

  # Validate final icon choice (after any publish_marker override)
  icon <- match.arg(icon)

  # default vertical offset to offset_px so existing calls don't change
  if (is.null(offset_y_px)) offset_y_px <- offset_px

  preset_fg <- switch(
    icon,
    "tick"  = tick_hex,
    "cross" = cross_hex,
    "stop"  = stop_hex,
    "#505a5f"
  )
  fg_hex <- if (is.null(fg_hex)) preset_fg else fg_hex

  # Icon glyphs
  icon_node <- switch(
    icon,
    "i"     = "i",
    "?"     = "?",
    "tick"  = "\u2713", # ✓
    "cross" = "\u2715", # ✕
    "stop"  = "\u2212"  # − (keep as you currently have it)
  )

  # Wrapper positioning:
  # - corner NULL  => in-flow element; flexbox gap/margins work
  # - corner set   => absolute overlay in chosen corner (previous behaviour)
  wrap_style <- if (is.null(corner)) {
    "position: relative; display: inline-block; z-index: 2;"
  } else {
    corner_style <- switch(
      corner,
      "top-right" = paste0("top:", offset_y_px, "px; right:", offset_px, "px;"),
      "top-left"  = paste0("top:", offset_y_px, "px; left:",  offset_px, "px;")
    )
    paste0("position: absolute;", corner_style, "z-index:2;")
  }

  htmltools::tags$span(
    class = "govuk-info-wrap",
    style = wrap_style,

    htmltools::tags$span(
      id = id,
      role = "button",
      tabindex = "0",
      `aria-describedby` = paste0(id, "-tooltip"),
      class = "govuk-info-btn",
      title = if (!is.null(title)) title else NULL,
      style = paste0(
        "display:inline-flex; align-items:center; justify-content:center;",
        "width:22px; height:22px; border-radius:50%;",
        "border:1px solid ", fg_hex, "; color:", fg_hex, ";",
        "background:", bg_hex, ";",
        "font-weight:700; font-family:inherit; font-size:13px; line-height:1;",
        "cursor:default; user-select:none;"
      ),
      icon_node
    ),

    htmltools::tags$span(
      id = paste0(id, "-tooltip"),
      role = "tooltip",
      class = "govuk-info-tooltip",
      style = paste0(
        "position:absolute;",
        "min-width:220px; max-width:320px;",
        "padding:10px 12px; border-radius:3px;",
        "background:", tooltip_bg, "; color:", tooltip_fg, ";",
        "box-shadow:0 4px 12px rgba(0,0,0,0.2);",
        "font-size:14px; line-height:1.4;"
      ),
      text
    )
  )
}
