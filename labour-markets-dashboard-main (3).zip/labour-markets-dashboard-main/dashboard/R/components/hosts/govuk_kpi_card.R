
#' GOV.UK-style statistics summary card
#'
#' Displays a headline value and optional delta tag with a short period label.
#'
#' @param id HTML id for the card.
#' @param title Short title above the headline.
#' @param headline Character or numeric; main value (use `format_headline` for numeric).
#' @param delta Optional character or numeric change (use `format_delta` for numeric).
#' @param period Character label appended after delta (default "vs last month").
#' @param accent_hex Hex colour for the top border (default "#cf102d").
#' @param good_if_increase Logical; TRUE -> positive is good (green).
#' @param tag_colour Optional override: "green"|"red"|"blue".
#' @param width_class GOV.UK grid class for width.
#' @param classes Extra classes on the summary card.
#' @param format_headline Optional function to format numeric `headline`.
#' @param format_delta Optional function to format numeric `delta`.
#' @return An `htmltools` tag `<div>`.
#' @examples
#' govuk_stats_card(
#'   id = "rate",
#'   title = "Unemployment rate",
#'   headline = 4.9,
#'   delta = -0.3,
#'   period = "vs last month",
#'   format_headline = govuk_format_percent1,
#'   format_delta = govuk_format_percent1,
#'   good_if_increase = FALSE
#' )
#' @export
#' GOV.UK-style statistics summary card (supports multiple delta tags)
#'
#' Drop-in replacement that fixes tag-colour inference:
#' - Colours are inferred from RAW numeric delta (not formatted strings)
#' - Vectorised deltas + labels supported
#' - NA-safe (NA deltas -> blue by default)
#'
#' @export
govuk_kpi_card <- function(
  id,
  title,
  headline,                  # formatted string OR numeric; main value
  delta = NULL,              # formatted string OR numeric; vector allowed
  period = "vs last month",  # scalar or vector label(s)
  accent_hex = "#cf102d",    # top border accent
  good_if_increase = TRUE,   # TRUE: increase => green; FALSE: increase => red
  tag_colour = NULL,         # override: 'green'|'red'|'blue' (scalar or vector)
  width_class = "govuk-grid-column-one-third",
  classes = NULL,
  format_headline = NULL,
  format_delta = NULL,
  subtext = NULL,
  # info control
  show_info = FALSE,
  info_text = NULL,
  info_icon = c("i", "?", "tick", "cross", "stop"),
  info_corner = c("top-right", "top-left"),
  publish_marker = c("public", "public_micro", "private_micro")
) {
  info_icon   <- match.arg(info_icon)
  info_corner <- match.arg(info_corner)

  # ---- Headline (display) ----
  headline_out <- if (!is.null(format_headline)) format_headline(headline) else headline

  # ---- Delta(s) (raw + display) ----
  delta_tags <- NULL

  if (!is.null(delta)) {

    # Keep RAW delta for colour inference (this is the critical fix)
    delta_raw <- delta

    # Display delta(s)
    delta_out <- if (!is.null(format_delta) && is.numeric(delta_raw)) {
      format_delta(delta_raw)
    } else {
      delta_raw
    }
    delta_out <- as.character(delta_out)

    # Period labels: scalar or vector; recycle to match delta length
    period_out <- if (length(period) == 1L) rep(period, length(delta_out)) else period
    period_out <- rep(period_out, length.out = length(delta_out))

    # Determine tag colours
    tag_cols <- NULL

    if (!is.null(tag_colour)) {
      # Override can be scalar or vector; recycle
      tag_cols <- rep(tag_colour, length.out = length(delta_out))
      tag_cols[!tag_cols %in% c("green", "red", "blue")] <- "blue"
    } else {
      # Infer from RAW numeric deltas when possible.
      # If delta_raw isn't numeric, we try a safe parse of delta_raw itself,
      # NOT the formatted delta_out (avoids commas/Unicode minus issues).
      delta_num <- if (is.numeric(delta_raw)) {
        as.numeric(delta_raw)
      } else {
        # best-effort parse of user-provided non-numeric deltas:
        # - replace unicode minus with '-'
        # - strip commas
        suppressWarnings(as.numeric(gsub(",", "", gsub("\u2212", "-", as.character(delta_raw)))))
      }

      tag_cols <- vapply(delta_num, function(d_i) {
        if (is.na(d_i)) return("blue")  # NA-safe: don't call .govuk_tag_colour(NA)
        col <- .govuk_tag_colour(d_i, good_if_increase)
        if (!col %in% c("green", "red", "blue")) "blue" else col
      }, character(1))
    }

    # OPTIONAL: If you prefer to hide NA deltas entirely, uncomment:
    # keep <- !(is.na(delta_raw) | is.na(suppressWarnings(as.numeric(delta_raw))))
    # delta_out <- delta_out[keep]; period_out <- period_out[keep]; tag_cols <- tag_cols[keep]

    # Build one <strong> tag per delta
    delta_tags <- Map(
      function(d, p, col) {
        htmltools::tags$strong(
          class = paste0("govuk-tag govuk-tag--", col),
          paste(d, p)
        )
      },
      delta_out, period_out, tag_cols
    )
  }

  # ---- Render card ----
  htmltools::tags$div(
    class = width_class,
    htmltools::tags$div(
      id    = id,
      class = paste("govuk-summary-card", if (!is.null(classes)) classes else ""),
      style = paste0(
        "position:relative;",
        "padding:15px; background:#f3f2f1; border-top:4px solid ", accent_hex, ";"
      ),

      # Optional info button
      if (isTRUE(show_info) && !is.null(info_text) && nzchar(info_text)) {
        htmltools::tagList(
        govuk_info_button(
          id     = paste0(id, "-info"),
          text   = info_text,
          icon   = info_icon,
          corner = info_corner, 
          offset_y_px = 40
        ),
        govuk_info_button(
          id = paste0(id, "-publish-marker"),
          publish_marker = publish_marker,
          corner = info_corner
        )
        )
      },

      htmltools::tags$h3(
        class = "govuk-heading-s",
        style = "white-space: normal; line-height: 1.2;",
        htmltools::HTML(split_title_at(title, threshold = 25))
      ),

      htmltools::tags$h2(class = "govuk-heading-l", headline_out),
      
      # Optional subtext (under headline)
      if (!is.null(subtext) && nzchar(subtext)) {
        htmltools::tags$p(
          class = "govuk-body-s",
          style = "margin-top: -30px; margin-bottom: 30px; color: #505a5f;",
          subtext
        )
      },


      # Multiple tags container (wraps nicely)
      if (!is.null(delta_tags)) {
          htmltools::tags$div(
            class = "dbt-kpi-delta-wrap",
            delta_tags
          )
      }
    )
  )
}


# Build KPI Card Wrapper 
build_kpi_card <- function(
  id,
  title,
  schema, table,
  filter_col, filter_value,
  parse_mode,
  publish_marker, 
  value_col = "value",
  additional_info = "",
  good_if_increase = TRUE,
  format_headline,
  format_delta,
  period = "vs last month",
  info_icon = "i",
  date_fmt = "%B %Y",
  filters = NULL, 

  # NEW:
  delta_rows_back = 2L,
  delta_labels    = NULL
  
) {

  ns <- shiny::NS(id)

  shiny::renderUI({
    res <- get_latest_value_eq(
      schema       = schema,
      table        = table,
      date_col     = "time_period",
      filter_col   = filter_col,
      filter_value = filter_value,
      value_col    = value_col,
      additional_info = additional_info,
      mode         = "latest",
      parse_mode   = parse_mode,
      with_tooltip = TRUE,
      date_fmt     = date_fmt,
      filters = filters, 
      # NEW:
      delta_rows_back = delta_rows_back,
      delta_labels    = if (is.null(delta_labels)) rep(period, length(delta_rows_back)) else delta_labels
    )

    govuk_kpi_card(
      id       = ns("card"),
      title    = title,
      headline = res$value,
      delta    = res$delta,
      period   = res$period,   # vector labels go here
      good_if_increase = good_if_increase,
      format_headline  = format_headline,
      format_delta     = format_delta,
      subtext = res$date,
      show_info = TRUE,
      info_text = res$tooltip,
      info_icon = info_icon,
      publish_marker = publish_marker
    )
  })
}
