mod_govuk_data_vis_card_ui <- function(
  id,
  title,
  help_text = NULL,
  help_text_source = NULL,
  help_link = NULL,
  help_link_text = NULL,
  visual_content = NULL,
  table_content = NULL,
  controls = NULL,            # plain controls (shown in dropdown)
  accordion_controls = FALSE, # set to UI tags to enable accordion; FALSE => none
  query = NULL, 
  publish_marker = NULL
) {
  ns <- shiny::NS(id)

  # ---- General controls (if any) ----
  controls_resolved <- NULL
  if (!is.null(controls) && length(controls) > 0) {
    controls_resolved <- htmltools::tagList(controls)
  }

  # ---- Optional accordion (closed by default) ----
  accordion_ui     <- NULL
  accordion_assets <- NULL

  has_accordion <-
    !identical(accordion_controls, FALSE) &&
    !is.null(accordion_controls) &&
    length(accordion_controls) > 0

  if (has_accordion) {
    accordion_inner <- htmltools::tagList(accordion_controls)

    accordion_ui <- htmltools::div(
      id = ns("chart-controls-acc"),
      shinyBS::bsCollapse(
        id   = ns("chart_controls_collapse"),
        open = NULL,  # closed initially
        shinyBS::bsCollapsePanel(
          title = "Chart Controls",
          value = "chart-controls",
          accordion_inner
        )
      )
    )

    # Scoped CSS/JS for accordion cosmetics and dropdown behaviour
    accordion_assets <- htmltools::singleton(
      htmltools::tags$head(
        htmltools::tags$style(
          htmltools::HTML(sprintf("
            /* ======================= ACCORDION SCOPE ======================= */
            #%s .panel {
              border: 0 !important; box-shadow: none !important; background: transparent !important;
              margin-bottom: 0.5rem;
            }
            #%s .panel-heading {
              background: transparent !important; border: 0 !important; padding: 8px 0;
            }
            #%s .panel-title a {
              display: block; position: relative; padding-right: 28px;
              text-decoration: none; color: inherit;
              font-size: 20px;
              line-height: 1.3; cursor: pointer;
              user-select: none; -webkit-user-select: none; -ms-user-select: none;
              -webkit-tap-highlight-color: transparent;
              background: transparent !important; outline: none !important; box-shadow: none !important;
            }
            #%s .panel-title a:hover,
            #%s .panel-title a:focus,
            #%s .panel-title a:active,
            #%s .panel-title a:visited {
              text-decoration: none !important; color: inherit !important;
              background: transparent !important; outline: none !important; box-shadow: none !important;
            }
            #%s .panel-title a:focus-visible {
              outline: 2px dotted rgba(0,0,0,0.35); outline-offset: 2px;
            }
            #%s .panel-body {
              border-top: 0 !important; padding: 8px 0 0 0; background: transparent !important;
            }
            /* Chevron using Font Awesome 4 */
            #%s .panel-title a:after {
              content: '\\f078'; font-family: 'FontAwesome';
              position: absolute; right: 0; top: 50%%;
              transform: translateY(-50%%) rotate(0deg); transition: transform .2s ease;
              font-size: 12px; opacity: 0.8;
            }
            #%s .panel-title a[aria-expanded='true']::after {
              transform: translateY(-50%%) rotate(180deg);
            }

            /* ======================= DROPDOWN SCOPE ======================== */
            .lm-card-ukhsa .dropdown-menu {
              padding: 12px 14px;
              font-size: 14px;
              line-height: 1.35;
            }
            .lm-card-ukhsa .dropdown-menu .shiny-input-container > label,
            .lm-card-ukhsa .dropdown-menu .control-label {
              font-size: 14px;
              margin-bottom: 6px;
            }
            .lm-card-ukhsa .dropdown-menu .btn-group .btn {
              font-size: 13px;
            }
            .lm-card-ukhsa .dropdown-menu .btn:focus,
            .lm-card-ukhsa .dropdown-menu .btn:active,
            .lm-card-ukhsa .dropdown-menu .btn:hover {
              box-shadow: none !important; outline: none !important;
            }
          ",
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc"),
          ns("chart-controls-acc")
          ))
        ),
        # Keep dropdown open when toggling accordion header inside shinyWidgets::dropdown
        htmltools::tags$script(htmltools::HTML("
          $(document).on('click', '.sw-dropdown .dropdown-menu .panel-heading, \
                                 .sw-dropdown .dropdown-menu .panel-title a', function(e){
            e.stopPropagation();
          });
        "))
      )
    )
  }

  # ---- Filters dropdown: combine general controls and accordion (if any) ----
  dropdown_body <- htmltools::tagList(controls_resolved, accordion_ui)

  dropdown_btn <- NULL
  if (length(dropdown_body) > 0) {
    dropdown_btn <- shinyWidgets::dropdown(
      dropdown_body,
      label   = "Filters",
      style   = "material-circle",
      icon    = shiny::icon("sliders-h"),
      status  = "danger",
      size    = "md",
      right   = TRUE,
      tooltip = shinyWidgets::tooltipOptions(title = "Show filters")
    )
  }
  

publisher_marker_ui <- NULL
if (!is.null(publish_marker)) {
  publisher_marker_ui <- govuk_info_button(
    id             = ns("publish-marker"),   # see next section
    publish_marker = publish_marker,
    corner         = NULL
  )
}

publisher_marker_ui <- tagAppendAttributes(
  publisher_marker_ui,
  class = "ukhsa-title-info"
)

  # ---- Copy button CSS/behaviour (scoped, singleton) ----
  copy_code_assets <- htmltools::singleton(
  htmltools::tags$head(
    htmltools::tags$style(
      htmltools::HTML(paste0("
        /* ===================== CODE BLOCK COPY (SCOPED) ===================== */

        #", ns("download"), " .code-block-wrapper {
          position: relative;
          margin-top: 10px;
        }

        /* Give the <pre> breathing room so the icon doesn't overlap first line */
        #", ns("download"), " .code-block-wrapper pre {
          padding-top: 2.25rem !important;
        }

        #", ns("download"), " .copy-icon-btn {
          position: absolute;
          top: 8px;
          right: 28px; /* ← moved left by 20px (was 8px) */

          display: inline-flex;
          align-items: center;
          justify-content: center;

          width: 34px;
          height: 34px;
          border-radius: 8px;

          border: 1px solid rgba(0,0,0,0.12);
          background: rgba(255,255,255,0.92);
          color: rgba(0,0,0,0.65);

          cursor: pointer;
          transition:
            background 0.15s ease,
            border-color 0.15s ease,
            color 0.15s ease,
            transform 0.05s ease;
          z-index: 2;
        }

        #", ns("download"), " .copy-icon-btn:hover {
          background: rgba(255,255,255,1);
          color: rgba(0,0,0,0.85);
          border-color: rgba(0,0,0,0.18);
        }

        #", ns("download"), " .copy-icon-btn:active {
          transform: translateY(1px);
        }

        #", ns("download"), " .copy-icon-btn:focus,
        #", ns("download"), " .copy-icon-btn:focus-visible {
          outline: 3px solid rgba(29,112,184,0.35);
          outline-offset: 2px;
        }

        /* Micro-feedback */
        #", ns("download"), " .copy-icon-btn.is-copied {
          color: #00703c;
          border-color: rgba(0,112,60,0.35);
        }

        #", ns("download"), " .copy-icon-btn::after {
          content: 'Copied';
          position: absolute;
          right: 42px;
          top: 50%;
          transform: translateY(-50%);
          padding: 3px 8px;
          border-radius: 6px;
          background: rgba(0,0,0,0.78);
          color: #fff;
          font-size: 12px;
          line-height: 1;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.15s ease;
          white-space: nowrap;
        }

        #", ns("download"), " .copy-icon-btn.is-copied::after {
          opacity: 1;
        }

        /* Visually-hidden helper for aria-live */
        #", ns("download"), " .visually-hidden {
          position: absolute !important;
          width: 1px;
          height: 1px;
          margin: -1px;
          overflow: hidden;
          clip: rect(0,0,0,0);
          white-space: nowrap;
          border: 0;
        }
      "))
    )
  )
)

  # ---- Card structure: header + tabs + panels ----
  htmltools::tagList(
    accordion_assets,
    copy_code_assets,
    ukhsa_card_tabs_assets(),

    htmltools::tags$div(
      class = "lm-card-ukhsa",

      # Header
      htmltools::tags$div(
        class = "ukhsa-card-header",

        htmltools::tags$div(
          class = "ukhsa-card-header__left",

         
        htmltools::tags$h2(
          class = "govuk-heading-m ukhsa-card-title-inline",
      
          htmltools::tags$span(
            class = "ukhsa-card-title-text",
            title
          ),
      
          publisher_marker_ui
        ),
 

          # Help text (3 lines: description, Source, Link)
          if (!is.null(help_text)) htmltools::tags$p(
            class = "govuk-hint",

            # Line 1
            htmltools::tags$span(help_text),

            # Line 2 (Source)
            if (!is.null(help_text_source)) htmltools::tagList(
              htmltools::tags$br(),
              htmltools::tags$span(help_text_source)
            ),

            # Line 3 (Link)
            if (!is.null(help_link)) htmltools::tagList(
              htmltools::tags$br(),
              htmltools::tags$span("Link: "),
              htmltools::tags$a(
                href   = help_link,
                target = "_blank",
                rel    = "noopener noreferrer",
                help_link_text
              )
            )
          )
        ),

        htmltools::tags$div(
          class = "ukhsa-card-header__right",
          style = "position: relative;",
          dropdown_btn
        )
      ),

      # Tabs + panels
      htmltools::tags$div(
        class = "ukhsa-tabs",

        # Tab buttons
        htmltools::tags$div(
          class = "ukhsa-tabs__list", role = "tablist",
          htmltools::tags$a(
            class = "ukhsa-tabs__tab",
            role = "tab", `aria-selected` = "true", tabindex = "0",
            `data-target` = ns("chart"), "Chart"
          ),
          htmltools::tags$a(
            class = "ukhsa-tabs__tab",
            role = "tab", `aria-selected` = "false", tabindex = "-1",
            `data-target` = ns("table"), "Tabular data"
          ),
          htmltools::tags$a(
            class = "ukhsa-tabs__tab",
            role = "tab", `aria-selected` = "false", tabindex = "-1",
            `data-target` = ns("download"), "Source Data"
          )
        ),

        # Panels
        htmltools::tags$div(
          id = ns("chart"), class = "ukhsa-tabs__panel", role = "tabpanel",
          if (is.null(visual_content))
            htmltools::tags$p(class = "govuk-hint", "Visual Content placeholder")
          else visual_content
        ),

        htmltools::tags$div(
          id = ns("table"), class = "ukhsa-tabs__panel is-hidden", role = "tabpanel",
          if (is.null(table_content))
            htmltools::tags$p(class = "govuk-hint", "Table placeholder")
          else table_content
        ),

        # ---- Download panel (updated copy UX) ----
        htmltools::tags$div(
          id = ns("download"),
          class = "ukhsa-tabs__panel is-hidden",
          role = "tabpanel",

          # Title + body text with hyperlink
          htmltools::tags$h3("Sourcing the Data"),
          htmltools::tags$p(
            "To source the underlying data behind this visualisation, you can copy the SQL query below into ",
            htmltools::tags$a(
              href = "https://data.trade.gov.uk/data-explorer/",  # <-- replace
              target = "_blank",
              rel = "noopener noreferrer",
              "Data Explorer."
            ),
            "This will allow you to export it to Excel, CSV, etc. Additionally, you can use the ",
             htmltools::tags$a(
              href = "https://dbi.r-dbi.org/reference/dbGetQuery.html",  # <-- replace
              target = "_blank",
              rel = "noopener noreferrer",
              "DBI package"
            ),
            "to bring it into your R project."
          ),

          if (is.null(query)) {
            htmltools::tags$p(class = "govuk-hint", "Download placeholder")
          } else {

  # IDs (module-safe)
  raw_id  <- ns("query_code_container")      # existing raw SQL container
  raw_btn <- ns("copy_btn_sql")

  r_id    <- ns("query_r_code_pre")          # NEW: pre that will display R code
  r_btn   <- ns("copy_btn_r")

  # Helper: icon copy button (same look & feel as before)
  copy_icon_btn <- function(btn_id, copy_target_id, title = "Copy to clipboard") {
    htmltools::tags$button(
      id = btn_id,
      type = "button",
      class = "copy-icon-btn",
      title = title,
      onclick = sprintf(
        "
        (function(btn){
          var el = document.getElementById('%s');
          if(!el) return;
          var txt = el.innerText || el.textContent || '';

          function flash(){
            btn.classList.add('is-copied');
            setTimeout(function(){ btn.classList.remove('is-copied'); }, 1200);
          }

          if(navigator.clipboard && navigator.clipboard.writeText){
            navigator.clipboard.writeText(txt).then(flash).catch(function(){
              try{
                var ta = document.createElement('textarea');
                ta.value = txt;
                ta.setAttribute('readonly','');
                ta.style.position = 'absolute';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
                flash();
              } catch(e) {}
            });
          } else {
            try{
              var ta = document.createElement('textarea');
              ta.value = txt;
              ta.setAttribute('readonly','');
              ta.style.position = 'absolute';
              ta.style.left = '-9999px';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              flash();
            } catch(e) {}
          }
        })(this);
        ",
        copy_target_id
      ),
      bsicons::bs_icon("clipboard", size = "1.05em", title = title)
    )
  }

  htmltools::tagList(

    # --- Block 1: Raw SQL (unchanged, with copy icon) ---
    htmltools::tags$div(
      class = "code-block-wrapper",

      copy_icon_btn(raw_btn, raw_id, "Copy SQL"),

      htmltools::tags$div(
        id = raw_id,
        class = "code-block",
        shiny::verbatimTextOutput(query)
      )
    ),

    # spacer
    htmltools::tags$div(style = "height: 10px;")
  )
}
        )
      )
    ),

    htmltools::div(style = "height: 30px;"),

    # Card-level layout tweaks (your existing block retained)
htmltools::tags$style(htmltools::HTML("
  .lm-card-ukhsa .ukhsa-card-header {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: 12px; margin-bottom: 6px;
  }
  .lm-card-ukhsa .ukhsa-card-header__left { min-width: 0; }
  .lm-card-ukhsa .ukhsa-card-header__right { display: flex; flex-direction: row; gap: 6px; align-items: flex-end; align-items: center;}
  
    /* Make title + icon behave like inline text */
    .ukhsa-card-title-inline {
      display: inline-flex;
      flex-wrap: wrap;          /* allows natural line wrapping */
      align-items: flex-start;
      gap: 6px;                 /* space between last word and icon */
    }
    
    /* Ensure the text itself wraps correctly */
    .ukhsa-card-title-text {
      display: inline;
    }

        /* ================= TITLE INFO ICON MICRO CONTROL ================= */
        
        /* Base alignment hook */
        .lm-card-ukhsa .ukhsa-title-info {
          position: relative;      /* enable pixel nudging */
        }
        
        /* Vertical tweak */
        .lm-card-ukhsa .ukhsa-title-info {
          top: -4px;               /* ↑ move up (try -1px to -3px) */
        }
        
        /* Horizontal tweak (distance from last letter) */
        .lm-card-ukhsa .ukhsa-title-info {
          margin-left: 0px;        /* tighter or looser spacing */
        }

  .lm-card-ukhsa .ukhsa-tabs__panel {
    min-height: 400px;     /* baseline = chart tab height */
    max-height: 400px;     /* prevents the card growing beyond baseline */
    overflow-y: auto;      /* only show scrollbar when content exceeds max-height */
  }

      .lm-card-ukhsa .code-block {
        max-height: 200px;   /* whatever you want */
        overflow-y: auto;
      }


  .dropdown-menu { padding: 12px 14px; }
  .dropdown-menu .form-group, .dropdown-menu .sw-control, .dropdown-menu .shiny-input-container { margin-bottom: 10px; }
  @media (max-width: 640px) {
    .lm-card-ukhsa .ukhsa-card-header { flex-direction: column; align-items: stretch; gap: 8px; }
    .lm-card-ukhsa .ukhsa-card-header__right { justify-content: flex-end; }
  }
"))

  )
}

#' GOV.UK / UKHSA data-visualisation card (server)
#'
#' Minimal server module; triggers client-side initialisation of custom tabs.
#' Extend this to wire your outputs (tables, downloads, etc.).
#'
#' @param id Module id.
#' @return Invisibly initialises tab behaviour (side effects).
#'
#' @examples
#' # server <- function(input, output, session) {
#' #   mod_govuk_data_vis_card_server("jobs")
#' # }
mod_govuk_data_vis_card_server <- function(id) {
  shiny::moduleServer(id, function(input, output, session) {
    # Ensure the tab JS binds after render passes
    session$onFlushed(function() {
      session$sendCustomMessage("ukhsa-tabs-init", list())
    }, once = FALSE)
  })
}
