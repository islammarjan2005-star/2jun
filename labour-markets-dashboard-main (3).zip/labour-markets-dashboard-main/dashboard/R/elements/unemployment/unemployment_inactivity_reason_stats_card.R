unemployment_inactivity_reason_stats_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    # ---- Filters Row ----
    #tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "equal-height-buttons.css")),

    # ---- Your existing card ----
    mod_govuk_data_vis_card_ui(
      id = ns("unemployment_inactivity_reason_trend_card"),
      publish_marker = "public", 
      title = "Inactivity by Reason",
      help_text = "Seasonally Adjusted economic inactivity for people aged 16 to 64 by reason for inacitivty",
      help_text_source = "Source: ONS - A01 Labour market statistics summary data table 11",
      help_link = "https://data.trade.gov.uk/datasets/4609dc12-0dfa-4734-8ecb-6c50b59d163d", 
      help_link_text = "ONS Labour Market Overview",
      table_content = reactableOutput(ns("table"), height = "350px"),
      visual_content = plotlyOutput(ns("plot"),  height = "350px"),
      query = ns("sql_query"),
        controls =  list(
                      shinyWidgets::radioGroupButtons(
                       inputId = ns("group_by"),
                       label = "Group By",
                       choices = c("Reason",
                                   "Wants a Job Status"),
                       justified = TRUE,
                       status = "danger"
                    ),
                    mod_quick_date_range_ui(
                      id = ns("dates"),
                      label_quick = "Time Period",
                      label_picker  = "Time period",
                      custom_picker = "calendar",
                      presets = c("custom", "ytd", "past_year", "3y", "5y", "none")
                    ),
                    mod_filter_picker_ui(
                      id                 = ns("sector_filter"),
                      label              = "Reason Filtering",
                      multiple           = TRUE,
                      actions_box        = TRUE,
                      live_search        = TRUE,
                      virtual_scroll     = 10,
                      selected_text_format = "count > 2"
                    ),
                    mod_filter_picker_ui(
                      id                 = ns("group_filter"),
                      label              = "Want Job Filtering",
                      multiple           = TRUE,
                      actions_box        = TRUE,
                      live_search        = TRUE,
                      virtual_scroll     = 10,
                      selected_text_format = "count > 2"
                    )
      ),
        accordion_controls = list(
                    shinyWidgets::radioGroupButtons(
                      inputId = ns("chart_type"),
                      label   = "Choose a graph :",
                      choiceNames = list(
                        tags$span(`data-toggle`="tooltip", title = "Stacked Bar Chart", tags$i(class = "fa fa-bar-chart")),
                        tags$span(`data-toggle`="tooltip", title = "Line Chart",        tags$i(class = "fa fa-line-chart")),
                        tags$span(`data-toggle`="tooltip", title = "Area Chart",        tags$i(class = "fa fa-area-chart"))
                      ),
                      choiceValues = c("stacked_bar","line","stacked_area"),
                      justified = TRUE,
                      size = "sm",
                      status = "danger"
                    ),

                    conditionalPanel(
                      condition = sprintf("input['%s'] == 'stacked_bar'", ns("chart_type")),
                      shinyWidgets::sliderTextInput(
                        inputId = ns("stack_mode"),
                        label = "Time Interval between bars",
                        choices = c("monthly","quarterly","annually","5year","decade"),
                        selected = "annually",
                        grid = TRUE
                      ),
                      fluidRow(
                        column(
                          width = 6,
                        shinyWidgets::switchInput(
                        inputId = ns("annotation"),
                        label = "Show values?",
                        labelWidth = "80px",
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = TRUE
                      )),
                      column(
                        width = 6,
                        shinyWidgets::switchInput(
                        inputId = ns("totals"),
                        label = "Show totals?",
                        labelWidth = "80px",
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = TRUE
                      ))
                      )
                    ),
                    conditionalPanel(
                      condition = sprintf("input['%s'] == 'line'", ns("chart_type")),
                        shinyWidgets::switchInput(
                        inputId = ns("plot_mode"),
                        label = "Seperate group lines?",
                        labelWidth = "80px",
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = FALSE
                      )
                    ),
                    mod_annotation_line_ui(ns("date_lines"),
                          type = "date",
                          title = "Add key dates",
                          add_label = "Add key date",
                          show_delete = TRUE,
                          auto_mask_date = TRUE),

                    mod_annotation_line_ui(ns("value_lines"),
                          type = "value",
                          title = "Add key values",
                          add_label = "Add key values",
                          show_delete = TRUE,
                          auto_mask_date = TRUE)

                  )
    ))
}



## INACTIVITY REASON SERVER ## ----
unemployment_inactivity_reason_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session){
    
## 0) Defaults + annotations
shinyWidgets::updateRadioGroupButtons(session, "group_by", selected = "Reason")
date_lines  <- mod_annotation_line_server("date_lines",  type = "date")
value_lines <- mod_annotation_line_server("value_lines", type = "value")
shinyWidgets::updateRadioGroupButtons(session, "chart_type", selected = "stacked_bar")
    
#Reactive for the group by
group_by_col <- reactive({
  group <- input$group_by
  if(group == "Reason"){"inactivity_reason"} else if(group == "Wants a Job Status"){"want_job_status"}
})
    
#0.1) Convert plain text measure to var acceptable names
        # UI -> measure -> codes + labels
    

## 1) Get a full clean lazy table
  cleaned_full_tbl <- reactive({
    get_inactivity_by_reason_size_tbl()
    })
## 2) Build query variables from UI inputs 
     # Sector filtering
       sector <- mod_filter_picker_server(
      id       = "sector_filter",
      data_tbl = cleaned_full_tbl,
      column   = "inactivity_reason"
    )
       
      group_filter <- mod_filter_picker_server(
      id       = "group_filter",
      data_tbl = cleaned_full_tbl,
      column   = "want_job_status"
    )
    #Date Filtering
    dates <- mod_quick_date_range_server(
          id        = "dates",
          data_tbl  = cleaned_full_tbl,
          presets   = c("custom", "ytd", "past_year", "3y", "5y", "none"),
          default   = "5y", frequency = "monthly",
          custom_picker = "slider", 
          preserve_selection = TRUE
        )
  
## 3) Collect all variable inputs that drive the query
    query_inputs <- reactive({
      list(
        dates   = dates$date_range(),
        sector  = sector$selected(),
        group_filter = group_filter$selected(),
        group_col = group_by_col()
        
        
      )
    })
    
# 4) Debounce the *grouped* inputs (i.e, puts a delay on input from UI to it triggering the reactive, this prevents the query from updating too frequently, which causes instability in the app)
    query_inputs_deb <- debounce(query_inputs, 300)
   
# 5) Build data lazily off the debounced inputs
    dat <- eventReactive(query_inputs_deb(), {
          dr <- query_inputs_deb()$dates
          req(!is.null(dr), length(dr) == 2, !any(is.na(dr)))
          date_from <- as.Date(dr[[1]])
          date_to   <- as.Date(dr[[2]])
          group_col <- query_inputs_deb()$group_col
          
           t <- cleaned_full_tbl() %>%
            apply_filters_general(
              date_col  = "time_period",
              date_from = date_from,
              date_to   = date_to,
              where_in  = list(
                inactivity_reason = query_inputs_deb()$sector,
                want_job_status = query_inputs_deb()$group_filter
              ) # list(<col> = <values>)
             )
          
          list(
            data = t %>% dplyr::collect(),
            sql  = sql_render_pool_safe(t)
          )
        })
  
# 6) Outputs
    # Table
    output$table <- reactable::renderReactable({
      out <- dat()
      req(nrow(out$data) > 0)
      
      dbt_build_table(
        data = out$data,
        formatted_cols = c("value")   # <- just change this
      )
    })

    #SQL String
    output$sql_query <- renderText({ dat()$sql })
    
    # #Plot

output$plot <- plotly::renderPlotly({
  out <- dat(); req(nrow(out$data) > 0)

  # Optional safety if plot_mode might not exist sometimes:
  plot_mode  <- isTRUE(input$plot_mode)
  chart_type <- input$chart_type   # if you have rlang; otherwise just use input$chart_type

  if (plot_mode && chart_type == "line") {
    # line-specific tweaks go here later
    df_wants_job <- out$data %>% dplyr::filter(want_job_status == "Wants a job")
    df_doesnt__wants_job <- out$data %>% dplyr::filter(want_job_status == "Does not want a job")
    
      dbt_ts_plot(
    df = df_wants_job, df2 = df_doesnt__wants_job,
    dataset1_name = "Wants Job", dataset2_name = "Doesn't want Job",
    line_dash1 = "solid", line_dash2 = "dash",
    dataset1_group = "Wants Job - Solid", dataset2_group = "Doesn't want Job - Dash",
    chart_type = chart_type,
    bar_interval = input$stack_mode,
    bar_agg = "last",
    bar_show_segment_labels = input$annotation,
    bar_show_totals = input$totals,
    x_title = "Time period (YYYY‑MM)", y_title = "No.",
    palette = dbt_palettes$gaf, initial_legend_mode = "hidden",
    group_col = group_by_col(),
    vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
    hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()
  )
  } else {
  dbt_ts_plot(
    df = out$data,
    chart_type = chart_type,
    bar_interval = input$stack_mode,
    bar_agg = "last",
    bar_show_segment_labels = input$annotation,
    bar_show_totals = input$totals, y_title = "No.",
    palette = dbt_palettes$gaf, initial_legend_mode = "hidden",
    group_col = group_by_col(),
    vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
    hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()
  )
  }


})


})
}



get_inactivity_by_reason_size_tbl <- function() {
  #List out relevant dataset Identifier Codes 
 wants_job <- c("LF6F",	"LFP7",	"LF6H",	"LFP8",	"LF8B",	"LF6J")
 doesnt_want_job <- c("LF6L",	"LF6N",	"LF6P",	"LF6R",	"LF8E",	"LF6T")
 all_acceptable_codes <- c(wants_job, doesnt_want_job)


  base <- dplyr::tbl(APP_DB$pool, dbplyr::in_schema("ons", "labour_market__inactivity"))

  time_sql <- .date_sql_for("MMM-MMM YYYY", "time_period")

 base <- base %>% 
    dplyr::mutate(time_period = !!time_sql) %>% 
    dplyr::filter(dataset_identifier_code %in% all_acceptable_codes) %>% 
    dplyr::mutate(want_job_status = dplyr::if_else(
                      dataset_identifier_code %in% wants_job,
                      "Wants a job",
                      "Does not want a job"))

  base
}
