## UNEMPLOYMENT RATE KPI UI ## -----
unemployment_unemploy_rate_kpi_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("card"))
  )
}

## UNEMPLOYMENT RATE KPI SERVER ## -----
unemployment_unemploy_rate_kpi_card_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    output$card <- build_kpi_card(
      id              = session$ns("employ_rate"),
      title           = "Unemployment Rate",
      schema          = "ons",
      table           = "labour_market__age_group",
      filter_col      = "dataset_identifier_code",
      filter_value    = "MGSX",
      additional_info = "Aged 16+, seasonally adjusted",
      publish_marker = "public",
      parse_mode      = "MMM-MMM YYYY",
      good_if_increase = FALSE,
      format_headline = govuk_format_percent1,
      format_delta    = govuk_format_percent1_signed,
      delta_rows_back = c(2, 4, 13), 
      delta_labels = c("vs last month", "vs last quarter", "vs last year")
    )
  })
}
