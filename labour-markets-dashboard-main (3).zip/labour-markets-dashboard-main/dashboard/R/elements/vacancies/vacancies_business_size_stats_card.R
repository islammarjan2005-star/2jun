vacancies_business_size_stats_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    # ---- Filters Row ----
    #tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "equal-height-buttons.css")),

    # ---- Your existing card ----
    mod_govuk_data_vis_card_ui(
      id = ns("vacancies_business_size_trend_card"),
      publish_marker = "public", 
      title = "Vacancies by Business Size",
      help_text = "Seasonally Adjusted vacancies by size of business in the United Kingdom",
      help_text_source = "Source: ONS - A01 Labour market statistics summary data table 19",
      help_link = "https://data.trade.gov.uk/datasets/4609dc12-0dfa-4734-8ecb-6c50b59d163d", 
      help_link_text = "ONS Labour Market Overview",
      table_content = reactableOutput(ns("table"), height = "350px"),
      visual_content = plotlyOutput(ns("plot"),  height = "350px"), 
      query = ns("sql_query"), 
        controls =  list(
                      shinyWidgets::radioGroupButtons(
                       inputId = ns("which_measure"),
                       label = "Measure",
                       choices = c("Value", 
                                   "Value change on quarter",
                                   "Percentage change on quarter"),
                       justified = TRUE,
                       status = "danger"
                    ),
                    mod_quick_date_range_ui(
                      id = ns("dates"), 
                      label_quick = "Time Period", 
                      label_picker  = "Time period",
                      custom_picker = "calendar",     
                      presets = c("custom", "ytd", "past_year", "3y", "5y", "none")
                    ),
                    mod_filter_picker_ui(
                      id                 = ns("sector_filter"),
                      label              = "Sector Filtering",
                      multiple           = TRUE,
                      actions_box        = TRUE,
                      live_search        = TRUE,
                      virtual_scroll     = 10,
                      selected_text_format = "count > 2"
                    )
      ),
        accordion_controls = list(
                    shinyWidgets::radioGroupButtons(
                      inputId = ns("chart_type"),
                      label   = "Choose a graph :",
                      choiceNames = list(
                        tags$span(`data-toggle`="tooltip", title = "Stacked Bar Chart", tags$i(class = "fa fa-bar-chart")),
                        tags$span(`data-toggle`="tooltip", title = "Line Chart",        tags$i(class = "fa fa-line-chart")),
                        tags$span(`data-toggle`="tooltip", title = "Area Chart",        tags$i(class = "fa fa-area-chart"))
                      ),
                      choiceValues = c("stacked_bar","line","stacked_area"),
                      justified = TRUE,
                      size = "sm",
                      status = "danger"
                    ),
              
                    conditionalPanel(
                      condition = sprintf("input['%s'] == 'stacked_bar'", ns("chart_type")),
                      shinyWidgets::sliderTextInput(
                        inputId = ns("stack_mode"),
                        label = "Time Interval between bars",
                        choices = c("monthly","quarterly","annually","5year","decade"),
                        selected = "annually",
                        grid = TRUE
                      ),
                      fluidRow(
                        column(
                          width = 6, 
                        shinyWidgets::switchInput(
                        inputId = ns("annotation"), 
                        label = "Show values?",
                        labelWidth = "80px", 
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = TRUE
                      )),
                      column(
                        width = 6, 
                        shinyWidgets::switchInput(
                        inputId = ns("totals"), 
                        label = "Show totals?",
                        labelWidth = "80px", 
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = TRUE
                      ))
                      )
                    ),
                    mod_annotation_line_ui(ns("date_lines"),
                          type = "date",
                          title = "Add key dates",
                          add_label = "Add key date",
                          show_delete = TRUE,
                          auto_mask_date = TRUE),
    
                    mod_annotation_line_ui(ns("value_lines"),
                          type = "value",
                          title = "Add key values",
                          add_label = "Add key values",
                          show_delete = TRUE,
                          auto_mask_date = TRUE)

                  )
    )
  )
}

## BUSINESS SIZE SERVER ## ----
vacancies_business_size_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session){
    
## 0) Defaults + annotations
shinyWidgets::updateRadioGroupButtons(session, "which_measure", selected = "Value")
date_lines  <- mod_annotation_line_server("date_lines",  type = "date")
value_lines <- mod_annotation_line_server("value_lines", type = "value")
shinyWidgets::updateRadioGroupButtons(session, "chart_type", selected = "stacked_bar")
    


#Which Chart
    observeEvent(input$which_measure, {
  
        selected_chart <- dplyr::case_when(
          input$which_measure == "Value" ~ "stacked_bar",
          input$which_measure == "Value change on quarter"      ~ "line",
          input$which_measure == "Percentage change on quarter"      ~ "line",
          TRUE                                  ~ input$chart_type
        )
      
        shinyWidgets::updateRadioGroupButtons(
          session,
          inputId = "chart_type",
          selected = selected_chart
        )
      })
    
    
#0.1) COnvert plan text measure to var acceptable names
        # UI -> measure -> codes + labels
    measure_key <- reactive({
      switch(input$which_measure,
        "Value"                   = "value",
        "Value change on quarter"    = "change_on_quarter",
        "Percentage change on quarter" = "per_change",
        "value"
      )
    })
    
    y_axis_label <- reactive({
      switch(measure_key(),
        value        = "No.",
        change_on_quarter    = "No.",
        per_change = "% change on quarter",
        "No."
      )
    })
    
    y_auto_scale <- reactive({
      if(input$which_measure == "Value"){FALSE} 
      else if(input$which_measure == "Value change on quarter"){TRUE}
      else if(input$which_measure == "Percentage change on quarter"){TRUE} 
    })
    
    code_set <- list(
      value = c("AP2Y", "ALY5", "ALY6", "ALY7", "ALY8", "ALY9"),
      change_on_quarter = c("AP3K"),
      per_change = c("AP3L")
    )
    
    codes_cfg <- reactive({req(code_set[[measure_key()]]) ; code_set[[measure_key()]]})

## 1) Get a full clean lazy table
  cleaned_full_tbl <- reactive({
    cc <- codes_cfg()
      get_vacancy_by_business_size_tbl(codes = cc)
    }) %>% bindCache(measure_key())
## 2) Build query variables from UI inputs 
     # Sector filtering
    sector <- mod_filter_picker_server(
      id       = "sector_filter",
      data_tbl = cleaned_full_tbl,
      column   = "business_metric",
      defaults_pretty = c("1 - 9 employed",
                        "10 - 49 employed",
                        "50 - 249 employed",
                        "250 - 2,499 employed",
                        "2,500 + employed")
    )
    #Date Filtering
    dates <- mod_quick_date_range_server(
          id        = "dates",
          data_tbl  = cleaned_full_tbl,
          presets   = c("custom", "ytd", "past_year", "3y", "5y", "none"),
          default   = "5y", frequency = "monthly",
          custom_picker = "slider", 
          preserve_selection = TRUE
        )
  
## 3) Collect all variable inputs that drive the query
    query_inputs <- reactive({
      list(
        measure = measure_key(),
        dates   = dates$date_range(),
        sector  = sector$selected()
      )
    })
    
# 4) Debounce the *grouped* inputs (i.e, puts a delay on input from UI to it triggering the reactive, this prevents the query from updating too frequently, which causes instability in the app)
    query_inputs_deb <- debounce(query_inputs, 300)
   
# 5) Build data lazily off the debounced inputs
    dat <- eventReactive(query_inputs_deb(), {
          dr <- query_inputs_deb()$dates
          req(!is.null(dr), length(dr) == 2, !any(is.na(dr)))
          date_from <- as.Date(dr[[1]])
          date_to   <- as.Date(dr[[2]])
          
           t <- cleaned_full_tbl() %>%
            apply_filters_general(
              date_col  = "time_period",
              date_from = date_from,
              date_to   = date_to,
              where_in  = setNames(list(query_inputs_deb()$sector), "business_metric")  # list(<col> = <values>)
            )
          
          list(
            data = t %>% dplyr::collect(),
            sql  = sql_render_pool_safe(t)
          )
        })
  
# 6) Outputs
    # Table
    output$table <- reactable::renderReactable({
      out <- dat()
      req(nrow(out$data) > 0)
      
      dbt_build_table(
        data = out$data,
        formatted_cols = c("value")   # <- just change this
      )
    })
    
    #SQL String
    output$sql_query <- renderText({ dat()$sql })
    
    #Plot
     output$plot <- plotly::renderPlotly({
      out <- dat(); req(nrow(out$data) > 0)
      ylab <- y_axis_label()
      y_auto_scale <- y_auto_scale()
      dbt_ts_plot(
        df = out$data,
        chart_type = input$chart_type,
        bar_interval = input$stack_mode,
        initial_y_autoscale = y_auto_scale, 
        bar_agg = "last", bar_show_segment_labels = input$annotation, 
        bar_show_totals = input$totals,y_title = ylab, 
        palette = dbt_palettes$gaf, initial_legend_mode = "hidden",
        group_col = "business_metric", 
        group_order =  c(
                        "All vacancies",
                        "1 - 9 employed",
                        "10 - 49 employed",
                        "50 - 249 employed",
                        "250 - 2,499 employed",
                        "2,500 + employed",
                        "Change on quarter",
                        "Percentage change"
                      ),
        vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
        hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()

      )
    })

  })
}

## VACANCIES BY BUSIENSS SIZE DATA ## ---- 
get_vacancy_by_business_size_tbl<- function(codes){ 
  
  base <- dplyr::tbl(APP_DB$pool, dbplyr::in_schema("ons", "labour_market__vacancies_business"))
  
  #Time period Parsing and Conversion
  
  # Build SQL fragment for time_period parsing (or NULL)
  time_sql <- .date_sql_for("MMM-MMM YYYY", "time_period")
  
  
  base <- base %>% 
    dplyr::filter(dataset_identifier_code %in% !!codes) %>%
    dplyr::mutate(time_period = !!time_sql,
                    value = dplyr::if_else(
                      business_metric %in% c(
                        "1 - 9 employed",
                        "10 - 49 employed",
                        "2,500 + employed",
                        "250 - 2,499 employed",
                        "50 - 249 employed",
                        "All vacancies",
                        "Change on quarter"
                      ),
                      as.numeric(value) * 1000,
                      as.numeric(value)
                    )

    )
                

  base
  }
