## AWE TOTAL PAY KPI UI ## -----
vacancies_hospitality_kpi_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("card"))
  )
}

## AWE TOTAL PAY KPI SERVER ## -----
vacancies_hospitality_kpi_card_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    output$card <- build_kpi_card(
      id              = session$ns("overall_vacancies"),
      title           = "Accomodation & food service vacancies",
      schema          = "ons",
      table           = "labour_market__vacancies_industry",
      filter_col      = "dataset_identifier_code",
      filter_value    = "JP9O",
      additional_info = "SIC 2007 - I: Accomodation & food service activities, seasonally adjusted",
      publish_marker = "public",
      parse_mode      = "MMM-MMM YYYY",
      good_if_increase = TRUE,
      format_headline = function(x) govuk_format_number(x, digits = 0, uprate = 1000),
      format_delta    = function(x) govuk_format_number_signed(x, digits = 0, uprate = 1000),
      delta_rows_back = c(2, 4, 13), 
      delta_labels = c("vs last month", "vs last quarter", "vs last year")
    )
  })
}