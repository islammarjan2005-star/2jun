### REAL AWE STATS CARD ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

## REAL AWE UI ## -----
employment_real_awe_stats_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    # ---- Filters Row ----
    #tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "equal-height-buttons.css")),

    # ---- Your existing card ----
    mod_govuk_data_vis_card_ui(
      id = ns("real_awe_trend_card"),
      publish_marker = "public", 
      title = "Real Average Weekly Earnings",
      help_text = "Seasonally Adjusted Real Average Weekly Earnings in Great Britian",
      help_text_source = "Source: ONS - X09: Real average weekly earnings using consumer price inflation (seasonally adjusted)",
      help_link = "https://data.trade.gov.uk/datasets/4609dc12-0dfa-4734-8ecb-6c50b59d163d", 
      help_link_text = "ONS Labour Market Overview",
      table_content = reactableOutput(ns("table"), height = "350px"),
      visual_content = plotlyOutput(ns("plot"), height = "350px"), 
      query = ns("sql_query"), 
      controls =  list(
                      shinyWidgets::radioGroupButtons(
                       inputId = ns("which_measure"),
                       label = "Measure",
                       choices = c("Real Weekly Earnings (2015 £)", "Index Real Weekly Earnings (2015 = 100)", "% changes year on year"),
                       justified = TRUE,
                       status = "danger"
                    ), 
                    conditionalPanel(
                      condition = sprintf("input['%s'] == '%% changes year on year'", ns("which_measure")),
                          shinyWidgets::radioGroupButtons(
                           inputId = ns("which_percent"),
                           label = "Percentage",
                           choices = c("Single month", "3 month average"),
                           justified = TRUE,
                           selected = NULL, 
                           status = "danger"
                        )
                    ),
                    shinyWidgets::radioGroupButtons(
                       inputId = ns("earning_type"),
                       label = "Regular VS Total Pay",
                       choices = c("Regular",
                        "Total","Both"),
                       justified = TRUE,
                       status = "danger"
                    ),
                     mod_quick_date_range_ui(
                      id = ns("awe_dates"),
                      label_quick = "Time Period",
                      label_picker  = "Time period",
                      custom_picker = "calendar",
                      presets = c("custom", "ytd", "past_year", "3y", "5y", "none")
                    )
      ),
        accordion_controls = list(
                    mod_annotation_line_ui(ns("date_lines"),
                          type = "date",
                          title = "Add key dates",
                          add_label = "Add key date",
                          show_delete = TRUE,
                          auto_mask_date = TRUE),

                    mod_annotation_line_ui(ns("value_lines"),
                          type = "value",
                          title = "Add key values",
                          add_label = "Add key values",
                          show_delete = TRUE,
                          auto_mask_date = TRUE)
                  )
    )
  )
}

## Real AWE SERVER ## ----
employment_real_awe_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session){

    # Defaults + annotations
    shinyWidgets::updateRadioGroupButtons(session, "which_measure", selected = "Real Weekly Earnings (2015 £)")
    shinyWidgets::updateRadioGroupButtons(session, "earning_type",   selected = "Regular")
    date_lines  <- mod_annotation_line_server("date_lines",  type = "date")
    value_lines <- mod_annotation_line_server("value_lines", type = "value")

    # UI -> measure -> codes + labels
    earning_type_map <- reactive({
      if(input$earning_type == "Regular"){"Regular"} 
      else if(input$earning_type == "Total"){"Total"}
      else if(input$earning_type == "Both"){NULL} 
    })
    
    y_axis_lab <- reactive({
      if(input$which_measure == "Real Weekly Earnings (2015 £)"){"Real Weekly Earnings (2015 £)"} 
      else if(input$which_measure == "Index Real Weekly Earnings (2015 = 100)"){"Index Real Weekly Earnings (2015 = 100)"}
      else if(input$which_measure == "% changes year on year"){"% changes year on year"} 
    })
    
    percent <- reactive({
      if(input$which_measure == "Real Weekly Earnings (2015 £)"){NULL} 
      else if(input$which_measure == "Index Real Weekly Earnings (2015 = 100)"){NULL}
      else if(input$which_measure == "% changes year on year"){input$which_percent} 
    })
    
    y_auto_scale <- reactive({
      if(input$which_measure == "Real Weekly Earnings (2015 £)"){FALSE} 
      else if(input$which_measure == "Index Real Weekly Earnings (2015 = 100)"){TRUE}
      else if(input$which_measure == "% changes year on year"){TRUE} 
    })
    # Base cleaned view (lazy)
    cleaned_full_tbl <- reactive({
      get_real_awe_table()
    })

    #Picker & dates
    dates <- mod_quick_date_range_server(
      id        = "awe_dates",
      data_tbl  = cleaned_full_tbl,
      presets   = c("custom", "ytd", "past_year", "3y", "5y", "none"),
      default   = "5y", frequency = "monthly",
      custom_picker = "slider",
      preserve_selection = TRUE
    )

    
    # 1) Collect all inputs that drive the query
    query_inputs <- reactive({
      list(
        earning_type = earning_type_map(),
        earnings_metric = input$which_measure,        # already bound-cached upstream
        dates       = dates$date_range(),
        percentage = percent()
      )
    })
    
    # 2) Debounce the *grouped* inputs
    query_inputs_deb <- debounce(query_inputs, 300)


   
    # 3) Build data lazily off the debounced trigger
    dat <- eventReactive(query_inputs_deb(), {
      dr <- query_inputs_deb()$dates
      req(!is.null(dr), length(dr) == 2, !any(is.na(dr)))
      date_from <- as.Date(dr[[1]])
      date_to   <- as.Date(dr[[2]])
      
    
      t <- cleaned_full_tbl() %>%
        apply_filters_general(
          date_col  = "time_period",
          date_from = date_from,
          date_to   = date_to,
          where_in  = list(
                earnings_type = query_inputs_deb()$earning_type,
                earnings_metric = query_inputs_deb()$earnings_metric,
                time_basis = query_inputs_deb()$percentage
              )
        )
    
      list(
        data = t %>% dplyr::collect(),
        sql  = sql_render_pool_safe(t)
      )
    })


    # Outputs
      output$table <- reactable::renderReactable({
        out <- dat()
        req(nrow(out$data) > 0)
        
        dbt_build_table(
          data = out$data,
          formatted_cols = c("value")   # <- just change this
        )
      })

    
    output$sql_query <- renderText({ dat()$sql })

    output$plot <- plotly::renderPlotly({
      out <- dat(); req(nrow(out$data) > 0)
      y_label = y_axis_lab() 
      y_auto_scale = y_auto_scale()
      
      dbt_ts_plot(
        df = out$data,
        chart_type = "line",
        y_title = y_label,
        palette = dbt_palettes$gaf, initial_legend_mode = "hidden",
        group_col = "earnings_type", initial_y_autoscale = y_auto_scale, 
        vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
        hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()
      )

    })
  })
}


get_real_awe_table <- function(){

  out <- dplyr::tbl(APP_DB$pool, dbplyr::in_schema("ons", "labour_market__weekly_earnings_cpi"))
  cast_date_sql <- dbplyr::sql("CAST(time_period AS DATE)")
  
  out <- out %>% 
    dplyr::mutate(
    time_period = !!cast_date_sql) %>%
     dplyr::mutate(
       earnings_type = dplyr::case_when(
        earnings_type %in% "Total pay, seasonally adjusted" ~ "Total",
        earnings_type %in% "Regular Pay, seasonally adjusted" ~ "Regular"
     )
     ) %>% 
     dplyr::mutate(
       	earnings_metric = dplyr::case_when(
        earnings_metric %in% "Real AWE(2015 £)" ~ "Real Weekly Earnings (2015 £)",
        earnings_metric %in% "Real AWE (Index numbers 2015=100)" ~ "Index Real Weekly Earnings (2015 = 100)",
        earnings_metric %in% "% changes year on year" ~ "% changes year on year"
     )
     ) 
    
  out
}

