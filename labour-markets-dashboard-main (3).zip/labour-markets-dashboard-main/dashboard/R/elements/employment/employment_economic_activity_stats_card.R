employment_economic_activity_stats_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    # ---- Filters Row ----
    #tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "equal-height-buttons.css")),

    # ---- Your existing card ----
    mod_govuk_data_vis_card_ui(
      id = ns("employment_economic_activity_trend_card"),
      publish_marker = "public", 
      title = "Economic Activity",
      help_text = "Seasonally Adjusted economic activity levels, including headline and those aged 16-64 and 16+.",
      help_text_source = "Source: ONS - A01 Labour market statistics summary data table 1 and 2",
      help_link = "https://data.trade.gov.uk/datasets/4609dc12-0dfa-4734-8ecb-6c50b59d163d", 
      help_link_text = "ONS Labour Market Overview",
      table_content = reactableOutput(ns("table"), height = "350px"),
      visual_content = plotlyOutput(ns("plot"),  height = "350px"),
      query = ns("sql_query"),
        controls =  list(
                      shinyWidgets::radioGroupButtons(
                       inputId = ns("group_by"),
                       label = "Show",
                       choices = c("Headline Only",
                                   "All stats"),
                       justified = TRUE,
                       status = "danger"
                    ),
                      shinyWidgets::radioGroupButtons(
                       inputId = ns("measure"),
                       label = "Measure",
                       choices = c("Level",
                                   "Rate"),
                       justified = TRUE,
                       status = "danger"
                    ),
                    mod_quick_date_range_ui(
                      id = ns("dates"),
                      label_quick = "Time Period",
                      label_picker  = "Time period",
                      custom_picker = "calendar",
                      presets = c("custom", "ytd", "past_year", "3y", "5y", "none")
                    ),
                     mod_filter_picker_ui(
                      id                 = ns("age_filter"),
                      label              = "Age Group Filtering",
                      multiple           = TRUE,
                      actions_box        = TRUE,
                      live_search        = TRUE,
                      virtual_scroll     = 10,
                      selected_text_format = "count > 2"
                    ),
                    mod_filter_picker_ui(
                      id                 = ns("statistic_filter"),
                      label              = "Statistic to display",
                      multiple           = TRUE,
                      actions_box        = TRUE,
                      live_search        = TRUE,
                      virtual_scroll     = 10,
                      selected_text_format = "count > 2"
                    )

      ),
        accordion_controls = list(
                    shinyWidgets::radioGroupButtons(
                       inputId = ns("chart_group_by"),
                       label = "Group By",
                       choices = c("Statistic",
                                   "Age Group"),
                       justified = TRUE,
                       status = "danger"
                    ),
                    shinyWidgets::radioGroupButtons(
                      inputId = ns("chart_type"),
                      label   = "Choose a graph :",
                      choiceNames = list(
                        tags$span(`data-toggle`="tooltip", title = "Stacked Bar Chart", tags$i(class = "fa fa-bar-chart")),
                        tags$span(`data-toggle`="tooltip", title = "Line Chart",        tags$i(class = "fa fa-line-chart")),
                        tags$span(`data-toggle`="tooltip", title = "Area Chart",        tags$i(class = "fa fa-area-chart"))
                      ),
                      choiceValues = c("stacked_bar","line","stacked_area"),
                      justified = TRUE,
                      size = "sm",
                      status = "danger"
                    ),

                    conditionalPanel(
                      condition = sprintf("input['%s'] == 'stacked_bar'", ns("chart_type")),
                      shinyWidgets::sliderTextInput(
                        inputId = ns("stack_mode"),
                        label = "Time Interval between bars",
                        choices = c("monthly","quarterly","annually","5year","decade"),
                        selected = "annually",
                        grid = TRUE
                      ),
                      fluidRow(
                        column(
                          width = 6,
                        shinyWidgets::switchInput(
                        inputId = ns("annotation"),
                        label = "Show values?",
                        labelWidth = "80px",
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = TRUE
                      )),
                      column(
                        width = 6,
                        shinyWidgets::switchInput(
                        inputId = ns("totals"),
                        label = "Show totals?",
                        labelWidth = "80px",
                        size = "mini",
                        offStatus = "danger",
                        onStatus = "danger",
                        value = TRUE
                      ))
                      )
                    ),
                    mod_annotation_line_ui(ns("date_lines"),
                          type = "date",
                          title = "Add key dates",
                          add_label = "Add key date",
                          show_delete = TRUE,
                          auto_mask_date = TRUE),

                    mod_annotation_line_ui(ns("value_lines"),
                          type = "value",
                          title = "Add key values",
                          add_label = "Add key values",
                          show_delete = TRUE,
                          auto_mask_date = TRUE)

                  )
    ))
}

employment_economic_activity_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session){
    
## 0) Defaults + annotations
 shinyWidgets::updateRadioGroupButtons(session, "group_by", selected = "Headline Only")
 shinyWidgets::updateRadioGroupButtons(session, "measure", selected = "Level")
date_lines  <- mod_annotation_line_server("date_lines",  type = "date")
value_lines <- mod_annotation_line_server("value_lines", type = "value")
shinyWidgets::updateRadioGroupButtons(session, "chart_type", selected = "stacked_bar")
shinyWidgets::updateRadioGroupButtons(session, "chart_group_by", selected = "Statistic")

    #Which Chart
    observeEvent(input$measure, {
  
        selected_chart <- dplyr::case_when(
          input$measure == "Level" ~ "stacked_bar",
          input$measure == "Rate"     ~ "line",
          TRUE                                  ~ input$chart_type
        )
      
        shinyWidgets::updateRadioGroupButtons(
          session,
          inputId = "chart_type",
          selected = selected_chart
        )
      })
    
#0.1) Convert plain text measure to var acceptable names
        # UI -> measure -> codes + labels
    headline_mode <- reactive({
      if(input$group_by == "Headline Only"){TRUE} else {NULL}
    })
    
    group_by_mode <- reactive({
      if(input$chart_group_by == "Statistic"){"statistic"} else {"age_group"}
    })
    
    y_axis_label <- reactive({
       if(input$measure == "Level"){"No."} else {"%"}
    })

## 1) Get a full clean lazy table
  cleaned_full_tbl <- reactive({
    get_age_tbl()
    })
## 2) Build query variables from UI inputs 
     # Sector filtering
      age_group_filt <- mod_filter_picker_server(
      id       = "age_filter",
      data_tbl = cleaned_full_tbl,
      column   = "age_group"
    )
      
    stat_filt <- mod_filter_picker_server(
      id       = "statistic_filter",
      data_tbl = cleaned_full_tbl,
      column   = "statistic"
    )
       

    #Date Filtering
    dates <- mod_quick_date_range_server(
          id        = "dates",
          data_tbl  = cleaned_full_tbl,
          presets   = c("custom", "ytd", "past_year", "3y", "5y", "none"),
          default   = "5y", frequency = "monthly",
          custom_picker = "slider",
          preserve_selection = TRUE
        )
  
## 3) Collect all variable inputs that drive the query
    query_inputs <- reactive({
      list(
        headline_mode = headline_mode(),
        measure_mode = input$measure,
        dates   = dates$date_range(),
        age_group_filt  = age_group_filt$selected(),
        stat_filt = stat_filt$selected()
        # group_col = group_by_col(),
        
        
        
      )
    })
    
# 4) Debounce the *grouped* inputs (i.e, puts a delay on input from UI to it triggering the reactive, this prevents the query from updating too frequently, which causes instability in the app)
    query_inputs_deb <- debounce(query_inputs, 300)
   
# 5) Build data lazily off the debounced inputs
    dat <- eventReactive(query_inputs_deb(), {
          dr <- query_inputs_deb()$dates
          req(!is.null(dr), length(dr) == 2, !any(is.na(dr)))
          date_from <- as.Date(dr[[1]])
          date_to   <- as.Date(dr[[2]])
          
            t <- cleaned_full_tbl() %>%
             apply_filters_general(
              date_col  = "time_period",
              date_from = date_from,
              date_to   = date_to,
              where_in  = list(
                age_group = query_inputs_deb()$age_group_filt,
                statistic = query_inputs_deb()$stat_filt
               ), # list(<col> = <values>)
               where_equals =  list(
                headline_stat = query_inputs_deb()$headline_mode,
                measure = query_inputs_deb()$measure_mode
              )
             )
          
          list(
            data = t %>% dplyr::collect(),
            sql  = sql_render_pool_safe(t)
          )
        })
  
# 6) Outputs
    # Table
    output$table <- reactable::renderReactable({
      out <- dat()
      req(nrow(out$data) > 0)
      
      dbt_build_table(
        data = out$data,
        formatted_cols = c("value")   # <- just change this
      )
    })


    #SQL String
    output$sql_query <- renderText({ dat()$sql })
    
    # #Plot

output$plot <- plotly::renderPlotly({
   out <- dat(); req(nrow(out$data) > 0)

  # Optional safety if plot_mode might not exist sometimes:
   group_mode  <- group_by_mode()
   chart_type <- input$chart_type   # if you have rlang; otherwise just use input$chart_type
   y_lab <-  y_axis_label()

  dbt_ts_plot(
    df = out$data,
    chart_type = chart_type,
    bar_interval = input$stack_mode,
    bar_agg = "last",
    bar_show_segment_labels = input$annotation,
    bar_show_totals = input$totals,
    y_title = y_lab,
    palette = dbt_palettes$gaf, initial_legend_mode = "hidden",
    group_col = group_mode,
    vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
    hlines = value_lines$values_out(), hline_labels = value_lines$labels_out()
  )



})


})
}


