## EMPLOYMENT BY AGE UI ## -----
employment_age_stats_card_ui <- function(id) {
  ns <- NS(id)
  tags$script("$(function() {$('[data-toggle=\"tooltip\"]').tooltip();});")

  mod_govuk_data_vis_card_ui(
    id = ns("age_trend_card"),
    publish_marker = "public", 
    title = "Employment by Age Group",
    help_text = "Employment levels and rates by age group.",
    help_text_source = "Source: ONS - A01 Labour market statistics summary data table 2",
    help_link = "https://data.trade.gov.uk/datasets/4609dc12-0dfa-4734-8ecb-6c50b59d163d", 
    help_link_text = "ONS Labour Market Overview",
    table_content  = reactableOutput(ns("table"), height = "350px"),
    visual_content = plotlyOutput(ns("age_plot"),  height = "350px"),
    query = ns("sql_query"),

    # Plain controls (stay visible in the dropdown)
    controls = list(
      shinyWidgets::radioGroupButtons(
        inputId = ns("which_measure"),
        label = "Level or Rate",
        choices = c("Level", "Rate"),
        justified = TRUE,
        status = "danger"
      ),

      mod_quick_date_range_ui(
        id = ns("age_dates"),
        label_quick = "Quick Ranges",
        label_picker  = "Time period",
        custom_picker = "slider",
        presets = c("custom", "ytd", "past_year", "3y", "5y", "none")
      ),
      mod_filter_picker_ui(
        id = ns("age_group_filter"),
        label = "Age Group Filtering",
        multiple = TRUE,
        actions_box = TRUE,
        live_search = TRUE,
        virtual_scroll = 10,
        selected_text_format = "count > 2"
      )
    ),

    # Inner UI for the accordion (module wraps/stylizes it)
    accordion_controls = list(
      shinyWidgets::radioGroupButtons(
        inputId = ns("chart_type"),
        label   = "Choose a graph :",
        choiceNames = list(
          tags$span(`data-toggle`="tooltip", title = "Stacked Bar Chart", tags$i(class = "fa fa-bar-chart")),
          tags$span(`data-toggle`="tooltip", title = "Line Chart",        tags$i(class = "fa fa-line-chart")),
          tags$span(`data-toggle`="tooltip", title = "Area Chart",        tags$i(class = "fa fa-area-chart"))
        ),
        choiceValues = c("stacked_bar","line","stacked_area"),
        justified = TRUE,
        size = "sm",
        status = "danger"
      ),

    conditionalPanel(
      condition = sprintf("input['%s'] == 'stacked_bar'", ns("chart_type")),
      shinyWidgets::sliderTextInput(
        inputId = ns("stack_mode"),
        label = "Bar Intervals and Annotations",
        choices = c("monthly","quarterly","annually","5year","decade"),
        selected = "annually", 
        grid = TRUE
      ),
      fluidRow(
        column(
          width = 6, 
        shinyWidgets::switchInput(
        inputId = ns("annotation"), 
        label = "Show values?",
        labelWidth = "80px", 
        size = "mini",
        offStatus = "danger",
        onStatus = "danger",
        value = TRUE
      )),
      column(
        width = 6, 
        shinyWidgets::switchInput(
        inputId = ns("totals"), 
        label = "Show totals?",
        labelWidth = "80px", 
        size = "mini",
        offStatus = "danger",
        onStatus = "danger",
        value = TRUE
      ))
      )
    ),

      mod_annotation_line_ui(ns("date_lines"),
        type = "date", title = "Add key dates",
        add_label = "Add key date", show_delete = TRUE, auto_mask_date = TRUE
      ),
      mod_annotation_line_ui(ns("value_lines"),
        type = "value", title = "Add key values",
        add_label = "Add key values", show_delete = TRUE, auto_mask_date = TRUE
      )
    )
  )
}

## EMPLOYMENT BY AGE SERVER ## -----
employment_age_stats_card_server <- function(id, conn = APP_DB$pool) {
  moduleServer(id, function(input, output, session) {

    # UI defaults + annotations
    shinyWidgets::updateRadioGroupButtons(session, "which_measure", selected = "Level")
    shinyWidgets::updateRadioGroupButtons(session, "chart_type", selected = "stacked_area")
    date_lines  <- mod_annotation_line_server("date_lines",  type = "date")
    value_lines <- mod_annotation_line_server("value_lines", type = "value")
    
    
    #Which Chart
    observeEvent(input$which_measure, {
  
        selected_chart <- dplyr::case_when(
          input$which_measure == "Level" ~ "stacked_area",
          input$which_measure == "Rate"     ~ "line",
          TRUE                                  ~ input$chart_type
        )
      
        shinyWidgets::updateRadioGroupButtons(
          session,
          inputId = "chart_type",
          selected = selected_chart
        )
      })

    
    
    # Reactive codes based on Level vs Rate selection
    codes <- reactive({
      sel <- input$which_measure %||% "Level"
      if (sel == "Level") {
        AGE_LEVEL_CODES
      } else {
        AGE_RATE_CODES
      }
    })

    # Y-axis label
    y_axis_label <- reactive({
      sel <- input$which_measure %||% "Level"
      if (sel == "Level") "Level" else "%"
    })

    # Base cleaned view (lazy)
    cleaned_full_tbl <- reactive({
      get_age_tbl(codes())
    }) %>% bindCache(input$which_measure)

    # Picker and Date modules
    sector <- mod_filter_picker_server(
      id       = "age_group_filter",
      data_tbl = cleaned_full_tbl,
      column   = "age_group"
    )
    dates <- mod_quick_date_range_server(
      id        = "age_dates",
      data_tbl  = cleaned_full_tbl,
      presets   = c("custom", "ytd", "past_year", "3y", "5y", "none"),
      default   = "5y", frequency = "monthly",
      custom_picker = "slider",
      preserve_selection = TRUE
    )

    # Final data (lazy filters -> collect + SQL)
    dat <- reactive({
      dr <- dates$date_range()
      date_from <- if (!is.null(dr) && length(dr) == 2) as.Date(dr[[1]]) else NULL
      date_to   <- if (!is.null(dr) && length(dr) == 2) as.Date(dr[[2]]) else NULL
      vals      <- sector$selected()

      t <- cleaned_full_tbl() %>%
        apply_filters_general(
          date_col     = "time_period",
          date_from    = date_from,
          date_to      = date_to,
          where_in     = list(age_group = vals)
        )

      list(
        data = t %>% dplyr::collect(),
        sql  = sql_render_pool_safe(t)
      )
    })

    # Outputs
    output$table <- reactable::renderReactable({
      out <- dat()
      req(nrow(out$data) > 0)
      
      dbt_build_table(
        data = out$data,
        formatted_cols = c("value")   # <- just change this
      )
    })

    output$sql_query <- renderText({ dat()$sql })
    output$age_plot <- plotly::renderPlotly({
      out <- dat(); req(nrow(out$data) > 0)
      dbt_ts_plot(
        df = out$data,
        chart_type = input$chart_type,
        bar_interval = input$stack_mode,
        bar_agg = "last",
        y_title = y_axis_label(),
        palette = dbt_palettes$gaf, initial_legend_mode = "hidden",
        group_col = "age_group",
        vlines = date_lines$values_out(), vline_labels = date_lines$labels_out(),
        hlines = value_lines$values_out(), hline_labels = value_lines$labels_out(),
        bar_show_segment_labels = input$annotation, 
        bar_show_totals = input$totals
      )
    })
  })
}

### EMPLOYMENT BY AGE CODES ## ------

# Level codes: employment levels (000s) by age group
AGE_LEVEL_CODES <- c("YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4")

# Rate codes: employment rates (%) by age group
AGE_RATE_CODES  <- c("YBUA", "YBUD", "YBUG", "YBUJ", "LF2U", "LFK6")

# Code-to-age-group mapping (shared by both level and rate codes)
AGE_CODE_MAP <- c(
  # Level codes
  "YBTO" = "16-17", "YBTR" = "18-24", "YBTU" = "25-34",
  "YBTX" = "35-49", "LF26" = "50-64", "LFK4" = "65+",
  # Rate codes
  "YBUA" = "16-17", "YBUD" = "18-24", "YBUG" = "25-34",
  "YBUJ" = "35-49", "LF2U" = "50-64", "LFK6" = "65+"
)


### EMPLOYMENT BY AGE DATA ## ------
get_age_tbl <- function(codes = NA_character_) {

  base <- dplyr::tbl(APP_DB$pool, dbplyr::in_schema("ons", "labour_market__age_group"))

  period_sql <- dbplyr::sql("
    to_date(
      initcap(substr(
        btrim(split_part(
          regexp_replace(
            btrim(regexp_replace(time_period::text, '\\\\s+', ' ', 'g')),
            '[\\u2013\\u2014]', '-', 'g'
          ),
          '-', 2
        )),
        1, 8
      )),
      'Mon YYYY'
    )::date
  ")

  # ---- codes handling: if NA/NULL/empty -> skip code filtering ----
  codes_vec <- codes
  do_code_filter <- !(is.null(codes_vec) || length(codes_vec) == 0L || all(is.na(codes_vec)))

  if (do_code_filter) {
    stopifnot(is.character(codes_vec))
    codes_vec <- unique(codes_vec[!is.na(codes_vec)])
    do_code_filter <- length(codes_vec) > 0L
  }

  out <- base
  if (do_code_filter) {
    out <- out %>% dplyr::filter(dataset_identifier_code %in% codes_vec)
  }

  out %>%
    dplyr::mutate(time_period = !!period_sql) %>%
    dplyr::mutate(
      age_group = dplyr::case_when(
        dataset_identifier_code %in% c("YBTO",	"YBUA",	"YBVH",	"YBVK",	"YBZL",	"YCAG",	"YCAS",	"LWEX") ~ "16-17",
        dataset_identifier_code %in% c("YBTR",	"YBUD",	"YBVN",	"YBVQ",	"YBZO",	"YCAJ",	"YCAV",	"LWFA") ~ "18-24",
        dataset_identifier_code %in% c("YBTU",	"YBUG",	"YCGM",	"YCGP",	"YBZR",	"YCAM",	"YCAY",	"LWFD") ~ "25-34",
        dataset_identifier_code %in% c("YBTX",	"YBUJ",	"YCGS",	"YCGV",	"YBZU",	"YCAP",	"YCBB",	"LWFG") ~ "35-49",
        dataset_identifier_code %in% c("LF26",	"LF2U",	"LF28",	"LF2E",	"LF3A",	"LF2C",	"LF2A",	"LF2W") ~ "50-64",
        dataset_identifier_code %in% c("LFK4",	"LFK6",	"K5HU",	"K5HW",	"LFK8",	"LFL2",	"LFL4",	"LFL6") ~ "65+",
        dataset_identifier_code %in% c("MGRZ",	"MGSR",	"MGSC",	"MGSX",	"MGSF",	"MGWG",	"MGSI",	"YBTC") ~ "16+",
        dataset_identifier_code %in% c("LF2G",	"LF24",	"LF2I",	"LF2Q",	"LF2K",	"LF22",	"LF2M",	"LF2S") ~ "16-64",
        TRUE ~ NA_character_
      )
    ) %>%
        dplyr::mutate(
      headline_stat = dplyr::case_when(
        dataset_identifier_code %in% c("MGRZ", "MGSC", "LF2M", "LF24", "MGSX", "LF2S") ~ TRUE,
        TRUE ~ FALSE
      )
    ) %>%
    dplyr::mutate(
      measure = dplyr::case_when(
        dataset_identifier_code %in% c("MGSR", "MGSX", "MGWG", "YBTC", "LF24", "LF2Q", "LF22", "LF2S", "YBUA", "YBVK", "YCAG", "LWEX", "YBUD", "YBVQ", "YCAJ", "LWFA", "YBUG", "YCGP", "YCAM", "LWFD", "YBUJ", "YCGV", "YCAP", "LWFG", "LF2U", "LF2E", "LF2C", "LF2W", "LFK6", "K5HW", "LFL2", "LFL6") ~ "Rate",
        dataset_identifier_code %in% c("MGRZ", "MGSC", "MGSF", "MGSI", "LF2G", "LF2I", "LF2K", "LF2M", "YBTO", "YBVH", "YBZL", "YCAS", "YBTR", "YBVN", "YBZO", "YCAV", "YBTU", "YCGM", "YBZR", "YCAY", "YBTX", "YCGS", "YBZU", "YCBB", "LF26", "LF28", "LF3A", "LF2A", "LFK4", "K5HU", "LFK8", "LFL4") ~ "Level",
        TRUE ~ NA
      )) %>%
    dplyr::mutate(
      statistic = dplyr::case_when(
        dataset_identifier_code %in% c("MGRZ", "MGSR", "LF2G", "LF24", "YBTO", "YBUA", "YBTR", "YBUD", "YBTU", "YBUG", "YBTX", "YBUJ", "LF26", "LF2U", "LFK4", "LFK6") ~ "Employment",
        dataset_identifier_code %in% c("MGSC", "MGSX", "LF2I", "LF2Q", "YBVH", "YBVK", "YBVN", "YBVQ", "YCGM", "YCGP", "YCGS", "YCGV", "LF28", "LF2E", "K5HU", "K5HW") ~ "Unemployment",
        dataset_identifier_code %in% c("MGSF", "MGWG", "LF2K", "LF22", "YBZL", "YCAG", "YBZO", "YCAJ", "YBZR", "YCAM", "YBZU", "YCAP", "LF3A", "LF2C", "LFK8", "LFL2") ~ "Activity",
        dataset_identifier_code %in% c("MGSI", "YBTC", "LF2M", "LF2S", "YCAS", "LWEX", "YCAV", "LWFA", "YCAY", "LWFD", "YCBB", "LWFG", "LF2A", "LF2W", "LFL4", "LFL6") ~ "Inactivity",
        TRUE ~ NA
      )) %>%
    dplyr::select(
      time_period,
      dataset_id = dataset_identifier_code,
      age_group,
      headline_stat,
      measure, 
      statistic,
      value
    )
}
