## AWE TOTAL PAY KPI UI ## -----
employment_awe_totalpay_kpi_card_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("card"))
  )
}

## AWE TOTAL PAY KPI SERVER ## -----
employment_awe_totalpay_kpi_card_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    output$card <- build_kpi_card(
      id              = session$ns("awe_totalpay"),
      title           = "Average Weekly Earnings",
      schema          = "ons",
      table           = "labour_market__weekly_earnings_cpi",
      filter_col      = NULL,
      filter_value    = NULL,
      filters         = list(  
                        earnings_type = "Total pay, seasonally adjusted", 
                        earnings_metric = "Real AWE(2015 £)"), 
      additional_info = "Total real pay (CPI‑adjusted to 2015 prices) in Great Britain, seasonally adjusted",
      publish_marker = "public",
      parse_mode      = "CAST_DATE",
      good_if_increase = TRUE,
      format_headline  = govuk_format_gbp,
      format_delta     = govuk_format_gbp_signed,
      delta_rows_back = c(2, 4, 13), 
      delta_labels = c("vs last month", "vs last quarter", "vs last year")
    )
  })
}